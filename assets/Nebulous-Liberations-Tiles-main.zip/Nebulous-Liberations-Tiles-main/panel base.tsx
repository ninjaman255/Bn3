<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="panel base" tilewidth="80" tileheight="55" tilecount="3" columns="3">
 <tileoffset x="-8" y="23"/>
 <image source="panel base.png" width="240" height="55"/>
</tileset>
