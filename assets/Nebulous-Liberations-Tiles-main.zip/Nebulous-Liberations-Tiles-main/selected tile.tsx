<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.1" name="selected tile" tilewidth="64" tileheight="32" tilecount="6" columns="3" objectalignment="top">
 <tileoffset x="0" y="-2"/>
 <image source="selected tile.png" width="192" height="64"/>
 <tile id="0">
  <animation>
   <frame tileid="0" duration="400"/>
   <frame tileid="1" duration="400"/>
  </animation>
 </tile>
 <tile id="1">
  <animation>
   <frame tileid="1" duration="320"/>
   <frame tileid="2" duration="34"/>
   <frame tileid="3" duration="34"/>
   <frame tileid="4" duration="34"/>
   <frame tileid="5" duration="128"/>
  </animation>
 </tile>
</tileset>
