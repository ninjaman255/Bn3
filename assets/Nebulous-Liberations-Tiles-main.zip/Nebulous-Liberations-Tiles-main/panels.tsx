<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="panels" tilewidth="50" tileheight="30" tilecount="70" columns="7" objectalignment="top">
 <tileoffset x="0" y="1"/>
 <image source="panels.png" width="350" height="300"/>
 <tile id="0">
  <animation>
   <frame tileid="0" duration="1000"/>
   <frame tileid="7" duration="500"/>
   <frame tileid="14" duration="500"/>
   <frame tileid="21" duration="1000"/>
   <frame tileid="14" duration="500"/>
   <frame tileid="7" duration="500"/>
  </animation>
 </tile>
 <tile id="1">
  <animation>
   <frame tileid="1" duration="1000"/>
   <frame tileid="8" duration="500"/>
   <frame tileid="15" duration="500"/>
   <frame tileid="22" duration="1000"/>
   <frame tileid="15" duration="500"/>
   <frame tileid="8" duration="500"/>
  </animation>
 </tile>
 <tile id="2">
  <animation>
   <frame tileid="2" duration="500"/>
   <frame tileid="9" duration="500"/>
   <frame tileid="16" duration="500"/>
   <frame tileid="23" duration="500"/>
   <frame tileid="16" duration="500"/>
   <frame tileid="9" duration="500"/>
  </animation>
 </tile>
 <tile id="3">
  <animation>
   <frame tileid="3" duration="320"/>
   <frame tileid="10" duration="320"/>
   <frame tileid="17" duration="320"/>
   <frame tileid="24" duration="320"/>
   <frame tileid="17" duration="320"/>
   <frame tileid="10" duration="320"/>
  </animation>
 </tile>
 <tile id="4">
  <animation>
   <frame tileid="4" duration="180"/>
   <frame tileid="11" duration="180"/>
   <frame tileid="18" duration="180"/>
   <frame tileid="25" duration="180"/>
   <frame tileid="32" duration="180"/>
   <frame tileid="39" duration="180"/>
   <frame tileid="46" duration="180"/>
   <frame tileid="53" duration="180"/>
   <frame tileid="60" duration="180"/>
   <frame tileid="67" duration="180"/>
  </animation>
 </tile>
 <tile id="5">
  <animation>
   <frame tileid="5" duration="180"/>
   <frame tileid="12" duration="180"/>
   <frame tileid="19" duration="180"/>
   <frame tileid="26" duration="180"/>
   <frame tileid="33" duration="180"/>
  </animation>
 </tile>
 <tile id="6">
  <animation>
   <frame tileid="6" duration="180"/>
   <frame tileid="13" duration="180"/>
   <frame tileid="20" duration="180"/>
   <frame tileid="27" duration="180"/>
   <frame tileid="34" duration="180"/>
  </animation>
 </tile>
</tileset>
