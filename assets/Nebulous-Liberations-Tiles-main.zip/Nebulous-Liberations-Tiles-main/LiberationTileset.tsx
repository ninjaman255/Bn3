<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="LiberationTileset" tilewidth="64" tileheight="36" tilecount="45" columns="5">
 <tileoffset x="0" y="4"/>
 <image source="LiberationTileset.png" width="320" height="324"/>
</tileset>
