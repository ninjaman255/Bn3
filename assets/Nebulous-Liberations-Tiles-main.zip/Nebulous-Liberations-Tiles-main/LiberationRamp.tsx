<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="LiberationRamp" tilewidth="64" tileheight="51" tilecount="4" columns="4">
 <tileoffset x="0" y="3"/>
 <image source="LiberationRamp.png" width="256" height="51"/>
 <tile id="0" type="Stairs">
  <properties>
   <property name="Direction" value="Up Right"/>
  </properties>
 </tile>
 <tile id="1" type="Stairs">
  <properties>
   <property name="Direction" value="Up Left"/>
  </properties>
 </tile>
 <tile id="2" type="Stairs">
  <properties>
   <property name="Direction" value="Up Right"/>
  </properties>
 </tile>
 <tile id="3" type="Stairs">
  <properties>
   <property name="Direction" value="Up Left"/>
  </properties>
 </tile>
</tileset>
