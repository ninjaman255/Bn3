<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="Liberation Collision" tilewidth="50" tileheight="30" tilecount="1" columns="1" objectalignment="top">
 <tileoffset x="0" y="1"/>
 <image source="Liberation Collision.png" width="50" height="30"/>
 <tile id="0">
  <objectgroup draworder="index" id="2">
   <object id="1" x="25" y="-2">
    <polygon points="0,0 33,17 0,34 -33,17"/>
   </object>
  </objectgroup>
 </tile>
</tileset>
