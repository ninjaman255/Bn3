<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="nebula door" tilewidth="63" tileheight="92" tilecount="12" columns="6" objectalignment="top">
 <tileoffset x="-39" y="-76"/>
 <grid orientation="isometric" width="64" height="32"/>
 <image source="nebula door.png" width="390" height="184"/>
 <tile id="0">
  <objectgroup draworder="index" id="2">
   <object id="1" x="24" y="-2" width="10" height="52"/>
  </objectgroup>
  <animation>
   <frame tileid="0" duration="150"/>
   <frame tileid="6" duration="150"/>
   <frame tileid="7" duration="150"/>
   <frame tileid="8" duration="150"/>
  </animation>
 </tile>
 <tile id="1">
  <objectgroup draworder="index" id="2">
   <object id="1" x="24" y="-2" width="10" height="52"/>
  </objectgroup>
 </tile>
 <tile id="2">
  <objectgroup draworder="index" id="2">
   <object id="1" x="24" y="-2" width="10" height="52"/>
  </objectgroup>
 </tile>
 <tile id="5">
  <objectgroup draworder="index" id="2">
   <object id="2" x="-8" y="24" width="60" height="11.6667"/>
  </objectgroup>
  <animation>
   <frame tileid="5" duration="150"/>
   <frame tileid="11" duration="150"/>
   <frame tileid="10" duration="150"/>
   <frame tileid="9" duration="150"/>
  </animation>
 </tile>
</tileset>
