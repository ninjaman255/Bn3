<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.1" name="attack indicator" tilewidth="48" tileheight="24" tilecount="1" columns="1" objectalignment="top">
 <tileoffset x="0" y="3"/>
 <image source="attack indicator.png" width="48" height="24"/>
</tileset>
