<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="walkable space" tilewidth="64" tileheight="32" tilecount="6" columns="2">
 <image source="walkable space.png" width="128" height="96"/>
 <tile id="4" type="Arrow">
  <properties>
   <property name="Direction" value="Up Right"/>
  </properties>
 </tile>
 <tile id="5" type="Arrow">
  <properties>
   <property name="Direction" value="Down Left"/>
  </properties>
 </tile>
</tileset>
