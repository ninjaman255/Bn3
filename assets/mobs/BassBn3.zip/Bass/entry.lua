local battle_helpers = include("battle_helpers.lua")
local character_info = { name = "Bass", hp = 1000, height = 73 }
local character_animation = _modpath .. "bass.animation"
local anim_speed = 1
local buster_sfx = Engine.load_audio(_folderpath .. "BusterRake.ogg")
local impact_sfx = Engine.load_audio(_folderpath .. "impact.ogg")
local earthbreak_sfx = Engine.load_audio(_folderpath .. "start.ogg")
local blast_texture = Engine.load_texture(_folderpath .. "bassblasts.png")
local earthbreak_texture = Engine.load_texture(_folderpath .. "earthbreak.png")
local CHARACTER_TEXTURE = Engine.load_texture(_modpath .. "bass.png")
local move_counter = 0
local auraChip = include("Aura/entry.lua")
local teleport_texture = Engine.load_texture(_folderpath .. "teleport.png")
local teleport_anim = _folderpath .. "teleport.animation"

---@param owner Entity the owner of the spell
---@param color string of the blast FX to be used.
---@param start_tile any if given, use this tile as the start tile.
local function spawn_blast(owner, color, start_tile)
    local owner_id = owner:get_id()
    local team = owner:get_team()
    local field = owner:get_field()
    local tile = owner:get_tile(owner:get_facing(), 1)
    if (start_tile) then
        tile = start_tile
    end

    local direction = owner:get_facing()
    ---@class Spell
    local spell = Battle.Spell.new(team)
    spell:highlight_tile(Highlight.Solid)
    spell:set_hit_props(HitProps.new(owner.blast_damage, Hit.Flash | Hit.Flinch, Element.None, owner_id, Drag.new()))
    spell.nextile = tile
    spell.wait_frames = 0
    local sprite = spell:sprite()
    sprite:set_texture(blast_texture)
    spell:set_offset(0, -50)

    local animation = spell:get_animation()
    animation:load(_folderpath .. "blast.animation")
    local animationState = color
    animation:set_state(animationState)
    animation:set_playback(Playback.Loop)
    animation:refresh(sprite)
    spell.update_func = function()
        if (spell.nextile == nil) then
            spell:erase()
        end
        spell.wait_frames = spell.wait_frames + 1
        if (spell.wait_frames == 6) then
            spell:teleport(spell.nextile)
            spell.nextile = spell.nextile:get_tile(direction, 1)
            spell.wait_frames = 0
        end
        spell:get_current_tile():attack_entities(spell)
    end

    spell.can_move_to_func = function()
        return true
    end

    spell.collision_func = function(self, dt)
        spell:get_current_tile():attack_entities(spell)
    end
    field:spawn(spell, spell.nextile)
end

---@param owner Entity the owner of the spell
local function spawn_impact(owner, tile)
    if (tile:is_edge()) then return end
    local owner_id = owner:get_id()
    local team = owner:get_team()
    local field = owner:get_field()
    local direction = owner:get_facing()
    ---@class Spell
    local spell = Battle.Spell.new(team)
    spell:highlight_tile(Highlight.Solid)
    spell:set_hit_props(HitProps.new(owner.blast_damage, Hit.Flash | Hit.Flinch, Element.None, owner_id, Drag.new()))
    spell.wait_frames = 0
    local sprite = spell:sprite()
    sprite:set_texture(earthbreak_texture)
    spell:set_offset(0, -50)

    local animation = spell:get_animation()
    animation:load(_folderpath .. "earthbreak.animation")
    animation:set_state("DEFAULT")
    animation:refresh(sprite)
    animation:on_complete(function()
        spell:get_current_tile():set_state(TileState.Broken);
        spell:erase()
    end)
    spell.update_func = function()
        spell:get_current_tile():attack_entities(spell)
    end

    spell.can_move_to_func = function()
        return true
    end

    spell.collision_func = function(self, dt)
        spell:get_current_tile():attack_entities(spell)
    end
    field:spawn(spell, tile)
end

---@param character Entity character to execute the action.
---@param state string State to put the character in after executing.
local function action_blast(character, state)
    local action = Battle.CardAction.new(character, "BUSTER")
    action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        self:add_anim_action(1, function()
            character:toggle_counter(true)
        end)
        action.action_end_func = function(self, user)
            character:toggle_counter(false)
            Engine.play_audio(buster_sfx, AudioPriority.Highest)
            local color = "GREEN"
            if (state == "repeat_buster_loop") then
                color = "YELLOW"
            end
            spawn_blast(character, color)
            character.animation = character:get_animation()
            character.animation:set_state("BUSTER_LOOP")
            character.animation:set_playback(Playback.Loop)
            character.state = state
            character.frame_counter = 0
        end
    end
    character:card_action_event(action, ActionOrder.Voluntary)
end

---@param character Entity character to execute the action.
---@param state string State to put the character in after executing.
local function action_earthbreak(character, state)
    local action = Battle.CardAction.new(character, "EARTHBREAK")
    action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        self:add_anim_action(2, function()
            character:toggle_counter(true)
        end)
        self:add_anim_action(4, function()
            character:toggle_counter(false)
            character:toggle_counter(false)
            character:shake_camera(4, 1)
            Engine.play_audio(impact_sfx, AudioPriority.Highest)
            spawn_impact(character, character:get_tile(character:get_facing(), 1))
            spawn_impact(character, character:get_tile(Direction.join(character:get_facing(), Direction.Up), 1))
            spawn_impact(character, character:get_tile(Direction.join(character:get_facing(), Direction.Down), 1))
        end)
    end
    character:card_action_event(action, ActionOrder.Voluntary)
end

local function move(self)
    move_counter = move_counter + 1
    local anim = self:get_animation()
    battle_helpers.spawn_visual_artifact(self:get_field(), self:get_tile(), teleport_texture, teleport_anim,
        "MEDIUM_TELEPORT_FROM",
        0, 0)
    battle_helpers.move_at_random(self)

    anim:on_complete(function()
        self:set_facing(self:get_tile():get_facing())
        anim:set_state("IDLE")
        anim:on_complete(function()
            self.wait_time = 0
        end)
    end)
end

local function moveToEnemyRow(self)
    move_counter = move_counter + 1
    local anim = self:get_animation()
    battle_helpers.spawn_visual_artifact(self:get_field(), self:get_tile(), teleport_texture, teleport_anim,
        "MEDIUM_TELEPORT_FROM",
        0, 0)
    battle_helpers.move_to_enemy_row(self)
    anim:on_complete(function()
        self:set_facing(self:get_tile():get_facing())
        anim:set_state("IDLE")
        anim:on_complete(function()
            action_blast(self, "buster_loop")
        end)
    end)
end

local function moveNearEnemy(self)
    move_counter = move_counter + 1
    local anim = self:get_animation()
    --anim:set_state("WARP_2")
    battle_helpers.spawn_visual_artifact(self:get_field(), self:get_tile(), teleport_texture, teleport_anim,
        "MEDIUM_TELEPORT_FROM",
        0, 0)
    battle_helpers.move_near_enemy(self)
end

local function moveToBackRow(self)
    move_counter = move_counter + 1
    local anim = self:get_animation()
    --anim:set_state("WARP_2")
    battle_helpers.spawn_visual_artifact(self:get_field(), self:get_tile(), teleport_texture, teleport_anim,
        "MEDIUM_TELEPORT_FROM",
        0, 0)
    battle_helpers.move_to_back_col(self)
    anim:on_complete(function()
        anim:set_state("IDLE")
        anim:on_complete(function()
            self:set_facing(self:get_tile():get_facing())
            action_blast(self, "repeat_buster_loop")
        end)
    end)
end

--Basic check to see if a tile is suitable for a chracter of a team to move to
function is_tile_free_for_movement(tile, character)

    if tile:get_team() ~= character:get_team() then
        return false
    end
    if (tile:is_edge()) then
        return false
    end
    local occupants = tile:find_entities(function(ent)
        if (Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil) then
            return true
        else
            return false
        end
    end)
    if #occupants == 1 and occupants[1]:get_id() == character:get_id() then
        return true
    end
    if #occupants > 0 then
        return false
    end

    return true
end

function flinchFunc()
    local anim = bass:get_animation()
    bass.flinching = true
    anim:set_state("HURT")
    anim:set_playback(Playback.Once)
    bass.set_state("hurt")
    bass.frame_counter = 0
end

bass = nil
---@param self Entity
function package_init(self)
    -- Load character resources
    move_counter = 0
    local base_animation_path = character_animation
    self:set_texture(CHARACTER_TEXTURE)
    self.animation = self:get_animation()
    self.animation:load(base_animation_path)
    self.animation:set_playback_speed(anim_speed)
    -- Set up character meta
    self:set_name(character_info.name)
    self:set_health(character_info.hp)
    self:set_height(character_info.height)
    self:share_tile(false)
    self:set_explosion_behavior(8, 1, true)
    self:set_offset(0, 0)
    self:set_air_shoe(true)
    self.animation:set_state("SPAWN")
    self.frames_between_actions = 26
    self.ai_wait = self.frames_between_actions
    self.ai_taken_turn = false
    self.wait_time = 0
    self.blast_damage = 100
    self.steps = 0
    self.state = "spawn"
    self.frame_counter = 0
    self.flinching = false
    bass = self
    -- Initial state

    self:register_status_callback(Hit.Flinch, flinchFunc)
    --utility to set the update state, and reset frame counter
    -- may not be the same as the animation state.
    self.set_state = function(state)
        self.state = state
        self.frame_counter = 0
    end

    self.can_move_to_func = function(tile)
        if (self.state == "bass_earthbreak") then
            return true
        else
            local canMove = is_tile_free_for_movement(tile, self)
            return canMove
        end
    end

    self.pick_special_attack = function()
        --todo: earthbreak and charged shot
        local rand = 1
        if (self:get_health() < 650) then
            rand = math.random(3)
        end
        if (rand == 1) then
            self.set_state("bass_multibuster")
        else
            self.set_state("bass_earthbreak")
        end

        self.steps = 0
    end

    self.regenAura = function()
        if (not self.aura_on) then
            self.barrier = auraChip.card_create_action(self)
            self.aura_on = true
        end
    end

    self.idle = function()
        self.state = "idle"
        self.animation:set_state("IDLE")
        self.set_state("idle")
    end

    self.update_func = function()
        self.frame_counter = self.frame_counter + 1
        if (self.state == "spawn") then
            self.aura_on = true
            self.barrier = auraChip.card_create_action(self)
            self.set_state("idle")
        end
        if (self.state == "idle") then
            self.wait_time = self.wait_time + 1
            if self.wait_time < self.ai_wait then
                return
            end
            self.steps = self.steps + 1
            if self.steps % 3 == 0 then
                if (self.steps == 9) then
                    self.pick_special_attack()
                else
                    self.set_state("bass_buster")
                end
            else
                move(self)
            end
            self.wait_time = 0
        elseif (self.state == "hurt") then
            if (self.frame_counter == 30) then
                bass.flinching = false
                self.idle()
                --idle, and reset steps if was using special attack.
                if (self.steps >= 9) then
                    self.steps = 0
                end
            end
        elseif (self.state == "buster_loop") then
            if (self.frame_counter == 53) then
                self.idle()
            end
        elseif (self.state == "bass_buster") then
            if (self.frame_counter == 1) then
                moveToEnemyRow(self)
            elseif (self.frame_counter > 10) then
                self.set_state("begin_bassbuster")
                action_blast(self, "buster_loop")
            end
        elseif (self.state == "bass_earthbreak") then
            if (self.frame_counter == 1) then
                Engine.play_audio(earthbreak_sfx, AudioPriority.Highest)
                moveNearEnemy(self)
                self.barrier.remove_barrier = true
                self.aura_on = false

            elseif (self.frame_counter == 3) then
                action_earthbreak(self)
            elseif (self.frame_counter > 80) then
                self.idle()
                self.regenAura()
            end
        elseif (self.state == "bass_multibuster") then
            if (self.frame_counter == 1) then
                moveToBackRow(self)
            end
        elseif (self.state == "repeat_buster_loop") then
            if (self.frame_counter % 15 == 0) then
                if (self.frame_counter < 90) then
                    Engine.play_audio(buster_sfx, AudioPriority.Highest)
                    local x = self:get_tile(self:get_facing(), 1):x()
                    local rand_y = math.random(3)
                    spawn_blast(self, "YELLOW", self:get_field():tile_at(x, rand_y))
                else
                    self.idle()
                    self.regenAura()

                end
            end
        end
    end
end
