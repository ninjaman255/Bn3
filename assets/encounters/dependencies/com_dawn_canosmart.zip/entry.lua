local package_id = "com.dawn.canosmart"
local character_id = "com.dawn.enemy.canosmart"

function package_requires_scripts()
  Engine.define_character(character_id, _modpath.."canosmart")
end

function package_init(package)
  package:declare_package_id(package_id)
  package:set_name("Canosmart")
  package:set_description("Me no dumb! Me smart! Try me!")
  package:set_speed(1)
  package:set_attack(100)
  package:set_health(500)
  package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
  mob
    :create_spawner(character_id, Rank.V1)
    :spawn_at(6, 1)
  mob
	:create_spawner(character_id, Rank.V1)
    :spawn_at(5, 2)
  mob
	:create_spawner(character_id, Rank.V1)
    :spawn_at(6, 3)
end
