local noop = function () end
local texture = nil
local animation_path = nil

local Cursor = {}

local function attack_tile(gunner, attack_spell, tile)
  if not tile then
    attack_spell:delete()
    return
  end
  Engine.play_audio(Engine.load_audio(_modpath.."gun.ogg"), AudioPriority.Highest)
  -- set the cursor up for damage
  local hitbox = Battle.Hitbox.new(gunner:get_team())
  hitbox:set_hit_props(HitProps.new(
    gunner._attack,
    Hit.Flinch | Hit.Impact,
    Element.Cursor,
    gunner:get_context(),
    Drag.None
  ))
  local fx = Battle.Artifact.new()
  fx:set_texture(texture)
  fx:set_facing(Direction.reverse(gunner:get_facing()))
  fx:set_palette(Engine.load_texture(_modpath.."gunner_v1.pallet.png"))
  local anim = fx:get_animation()
  anim:load(animation_path)
  anim:set_state("BURST")
  fx:sprite():set_layer(-2)
  anim:on_complete(function()
	fx:erase()
  end)
  gunner:get_field():spawn(hitbox, tile)
  gunner:get_field():spawn(fx, tile)
end

local function attack_tile_flinch(gunner, attack_spell, tile)
  if not tile then
    attack_spell:delete()
    return
  end
  Engine.play_audio(Engine.load_audio(_modpath.."gun.ogg"), AudioPriority.Highest)
  -- set the cursor up for damage
  local hitbox = Battle.Hitbox.new(gunner:get_team())
  hitbox:set_hit_props(HitProps.new(
    gunner._attack,
    Hit.Flinch | Hit.Impact | Hit.Flash,
    Element.Cursor,
    gunner:get_context(),
    Drag.None
  ))
  local fx = Battle.Artifact.new()
  fx:set_texture(texture)
  fx:set_facing(Direction.reverse(gunner:get_facing()))
  fx:set_palette(Engine.load_texture(_modpath.."gunner_v1.pallet.png"))
  local anim = fx:get_animation()
  anim:load(animation_path)
  anim:set_state("BURST")
  fx:sprite():set_layer(-2)
  anim:on_complete(function()
	fx:erase()	
  end)
  gunner:get_field():spawn(hitbox, tile)
  gunner:get_field():spawn(fx, tile)
end

local function attack(gunner, cursor)
	local gunner_anim = gunner:get_animation()
	gunner_anim:set_state("ATTACK")
	gunner._cursor_send_once = false
	gunner_anim:on_complete(function()
		gunner._cursor_send_once = true
		gunner._count_between_attack_sends = 30
	end)
	-- create a new attack spell to deal damage
	-- we can't deal damage to a target if we've hit them and they haven't moved
	local attack_spell = Battle.Spell.new(gunner:get_team())
	local tile = cursor.spell.tile
	cursor:erase()
	local direction = gunner:get_facing()
	local attack_cooldown = 10
	local hits = 0
	local query = function(ent)
		return ent ~= nil and not ent:is_deleted() and not ent:is_team(gunner:get_team())
	end
	local can_continue_moving = true
	attack_spell.update_func = function(self, dt)
		if attack_cooldown <= 0 then
			if hits < 2 then
				attack_tile(gunner, attack_spell, tile)
				attack_cooldown = 10
				hits = hits + 1
			else
				attack_tile_flinch(gunner, attack_spell, tile)
				gunner_anim:set_state("IDLE")
				self:delete()
			end
		else
			attack_cooldown = attack_cooldown - 1
		end
	end
	
	
	
	attack_spell.delete_func = function()
		attack_spell:erase()
	end
	attack_spell.attack_func = function()
		can_continue_moving = false
	end
	gunner:get_field():spawn(attack_spell, tile)
end

local function begin_attack(gunner, cursor)
  -- stop the cursor from scanning for players
  cursor.spell.update_func = noop
  cursor.spell.attack_func = noop

  local cursor_anim = cursor.spell:get_animation()
  cursor_anim:set_state("CURSOR_LOCKON")
  Engine.play_audio(Engine.load_audio(_modpath.."scanning_lock.ogg"), AudioPriority.High)
  cursor_anim:set_playback(Playback.Once)
  cursor_anim:on_complete(function()
    gunner._should_attack = true
  end)
end

local function spawn_cursor(cursor, gunner, tile)
	local spell = Battle.Spell.new(gunner:get_team())
	spell:set_facing(gunner:get_facing())
	spell:set_texture(gunner:get_texture(), true)
	spell:set_palette(Engine.load_texture(_modpath.."gunner_v1.pallet.png"))
	spell:sprite():set_layer(-1)
	spell:set_hit_props(HitProps.new(
		0,
		Hit.None,
		Element.None,
		gunner:get_context(),
		Drag.None
	))

	local anim = spell:get_animation()
	anim:load(animation_path)
	anim:set_state("CURSOR")
	Engine.play_audio(Engine.load_audio(_modpath.."scanning_click.ogg"), AudioPriority.High)
	anim:set_playback(Playback.Once)
	
	local field = gunner:get_field()
	field:spawn(spell, tile)
	spell.slide_started = false
	spell.update_func = function(action, dt)
		if gunner:get_rank() == Rank.V1 then
			if spell:get_current_tile():is_edge() and spell.slide_started then 
				gunner:get_animation():set_state("IDLE")
				spell:delete()
			end
		else
			if spell:get_current_tile():get_tile(spell:get_facing(), 1) then
				if spell:get_current_tile():get_tile(spell:get_facing(), 1):is_edge() or spell:get_tile():get_team() ~= gunner:get_team() and spell:get_current_tile():get_tile(spell:get_facing(), 1):get_team() == gunner:get_team() and spell:get_current_tile():get_tile(spell:get_facing(), 1):get_team() ~= Team.Other then
					spell:set_facing(Direction.reverse(spell:get_facing()))
				end
			end
		end
		tile = spell:get_tile(spell:get_facing(), 1)
		cursor.spell.tile = spell:get_tile()
		if not spell:is_sliding() then
			local ref = spell
			spell:slide(tile, frames(gunner._frames_per_cursor_movement), frames(0), ActionOrder.Voluntary, function()
				ref.slide_started = true
			end)
		end
	end
	
	spell.delete_func = function()
		gunner._count_between_attack_sends = 30
		spell:erase()
	end
	
	spell.collision_func = function(self, other)
		if Battle.Character.from(other) ~= nil then
			begin_attack(gunner, cursor)
		end
	end

	spell.can_move_to_func = function(tile)
		return true
	end

	return spell
end

function Cursor:new(gunner, tile)
  local cursor = {
    gunner = gunner,
    spell = nil,
    remaining_frames = gunner._frames_per_cursor_movement
  }

  setmetatable(cursor, self)
  self.__index = self

  cursor.spell = spawn_cursor(cursor, gunner, tile)

  return cursor
end

function Cursor:erase()
  self.spell:erase()
  self.gunner._cursor = nil
end

local delete_func = function(gunner)
	if gunner._cursor then
		gunner._cursor:erase()
	end
end

local target_update, idle_update

target_update = function(gunner, dt)
	if gunner._cursor then
		local spell = gunner._cursor.spell
		if gunner._cursor.spell:is_deleted() then
			gunner.update_func = idle_update
		else
			spell:get_current_tile():attack_entities(spell)

			if gunner._should_attack then
				gunner._should_attack = false
				attack(gunner, gunner._cursor)
			end
		end
	else
		gunner.update_func = idle_update
	end
end

idle_update = function(gunner, dt)
	local y = gunner:get_tile():y()
	local team = gunner:get_team()

	local field = gunner:get_field()
	local targets = field:find_characters(function(c)
		-- same row, different team
		return c:get_team() ~= team and c:get_tile():y() == y
	end)

	if #targets == 0 then return end -- no target
	if gunner._count_between_attack_sends <= 0 then
		if gunner._cursor_send_once then
			gunner._cursor_send_once = false
			gunner:get_animation():set_state("FOE_SPOTTED")
			gunner:get_animation():on_complete(function()
				-- found a target, spawn a cursor and change state
				local cursor_tile = gunner:get_tile()
				gunner._cursor = Cursor:new(gunner, cursor_tile)
				gunner.update_func = target_update
			end)
		end
	else
		gunner:get_animation():set_state("IDLE")
		gunner._count_between_attack_sends = gunner._count_between_attack_sends - 1
		gunner._cursor_send_once = true
	end
end

function package_init(gunner)
	if not texture then
		texture = Engine.load_texture(_modpath .. "gunner.greyscaled.png")
		animation_path = _modpath.."Gunner.animation"
	end

	-- private variables
	gunner._frames_per_cursor_movement = 15
	gunner._cursor = nil
	gunner._should_attack = false
	gunner._stop_updating_tile = false
	gunner._count_between_attack_sends = 0
	gunner._cursor_send_once = true
	gunner._attack = 0
	-- meta
	gunner:set_height(53)
	gunner:set_texture(texture, true)
	local rank = gunner:get_rank()
	if rank == Rank.V1 then
		gunner:set_name("Gunner")
		gunner:set_health(60)
		gunner._attack = 10
		gunner:set_palette(Engine.load_texture(_modpath.."gunner_v1.pallet.png"))
	elseif rank == Rank.V2 then
		gunner:set_name("Shooter")
		gunner:set_health(140)
		gunner._attack = 30
		gunner:set_palette(Engine.load_texture(_modpath.."gunner_v2.pallet.png"))
	elseif rank == Rank.V3 then
		gunner:set_name("Sniper")
		gunner:set_health(220)
		gunner._attack = 50
		gunner:set_palette(Engine.load_texture(_modpath.."gunner_v3.pallet.png"))
	end

	local anim = gunner:get_animation()
	anim:load(animation_path)
	anim:set_state("IDLE")

	-- setup defense rules
	gunner.defense = Battle.DefenseVirusBody.new() -- lua owns this need to keep it alive
	gunner:add_defense_rule(gunner.defense)

	-- setup event hanlders
	gunner.update_func = idle_update
	gunner.battle_start_func = noop
	gunner.battle_end_func = noop
	gunner.on_spawn_func = noop
	gunner.delete_func = delete_func
end