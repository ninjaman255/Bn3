local package_id = "com.Dawn.Viruses.Gunner"
local character_id = "com.Dawn.Viruses.Enemy.Gunner"

function package_requires_scripts()
  Engine.define_character(character_id, _modpath.."Gunner")
end

function package_init(package)
  package:declare_package_id(package_id)
  package:set_name("Gunner")
  package:set_description("Dig the trenches!")
  package:set_speed(1)
  package:set_attack(10)
  package:set_health(60)
  package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
  local field = mob:get_field()

  local tile = field:tile_at(4, 2)

  if not tile:is_walkable() then
    tile:set_state(TileState.Normal)
  end

  mob
    :create_spawner(character_id, Rank.V2)
    :spawn_at(6, 3)

  mob
    :create_spawner(character_id, Rank.V1)
    :spawn_at(4, 2)

  mob
    :create_spawner(character_id, Rank.V3)
    :spawn_at(6, 1)
end
