local package_id = "com.Dawn.BN3.Alpha"
local character_id = "com.Dawn.BN3.Alpha.BossFight"

function package_requires_scripts()
    Engine.define_character(character_id, _modpath.."virus")
end

function package_init(package) 
    package:declare_package_id(package_id)
    package:set_name("Alpha")
    package:set_description("The Internet is in danger!")
    package:set_speed(1)
    package:set_attack(100)
    package:set_health(2000)
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob) 
    local texPath = _modpath.."background.png"
    local animPath = _modpath.."background.animation"
    mob:set_background(texPath, animPath, 1.0, 0.0)
    mob:stream_music(_modpath.."song.mid", 0, 0)
    
    mob:create_spawner(character_id, Rank.V1):spawn_at(5, 2)
end