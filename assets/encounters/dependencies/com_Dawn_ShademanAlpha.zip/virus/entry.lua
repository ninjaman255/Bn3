local function create_noise_crush(shademan)
    local spell = Battle.Spell.new(shademan:get_team())
    spell:set_facing(shademan:get_facing())
    spell:highlight_tile(Highlight.Solid)
    spell:set_hit_props(
        HitProps.new(
            80,
            Hit.Impact | Hit.Pierce | Hit.Retangible,
            Element.None,
            shademan:get_context(),
            Drag.None
        )
    )
    local do_once = true
    local spell_timer = 999
    local forward_tile = nil
    local up_tile = nil
    local down_tile = nil
    local spawn_timer = 16
    local has_hit = false
    spell.update_func = function(self, dt)
        if do_once then
            spell_timer = 48
            do_once = false
            forward_tile = self:get_tile(self:get_facing(), 1)
            up_tile = forward_tile:get_tile(Direction.Up, 1)
            down_tile = forward_tile:get_tile(Direction.Down, 1)
        end
        if forward_tile and not forward_tile:is_edge() then forward_tile:highlight(Highlight.Solid) end
        if up_tile and not up_tile:is_edge() then up_tile:highlight(Highlight.Solid) end
        if down_tile and not down_tile:is_edge() then down_tile:highlight(Highlight.Solid) end
        if spawn_timer <= 0 then
            self:get_tile():attack_entities(self)
            forward_tile:attack_entities(self)
            up_tile:attack_entities(self)
            down_tile:attack_entities(self)
            if spell_timer <= 0 then
                self:delete()
            else
                spell_timer = spell_timer - 1
            end
        else
            spawn_timer = spawn_timer - 1
        end
    end
    spell.attack_func = function(self, other)
        local hitbox = Battle.Hitbox.new(self:get_team())
        local props = nil
        if other:is_moving() then
            props = HitProps.new(
                0,
                Hit.Root,
                Element.None,
                nil,
                Drag.None
            )
        else
            props = HitProps.new(
                0,
                Hit.Stun,
                Element.None,
                nil,
                Drag.None
            )
        end
        hitbox:set_hit_props(props)
        if not shademan:is_deleted() then
            shademan:get_field():spawn(hitbox, other:get_tile())
        end
        self:erase()
    end
    return spell
end

local function spawn_bat(shademan)
    local bat = Battle.Obstacle.new(shademan:get_team())
    bat:set_health(10)
    bat:set_facing(shademan:get_facing())
    local direction = bat:get_facing()
    bat:set_texture(shademan:get_texture())
    bat:set_name("Bat")
    local anim = bat:get_animation()
    anim:copy_from(shademan:get_animation())
    anim:set_state('10')
    anim:refresh(bat:sprite())
    anim:set_playback(Playback.Loop)
    bat.can_move_to_func = function(tile) return true end
    bat:set_hit_props(
        HitProps.new(
            80,
            Hit.Impact | Hit.Flash,
            Element.None,
            shademan:get_context(),
            Drag.None
        )
    )
    bat:sprite():set_layer(-1)
    bat:share_tile(true)
    bat.slide_started = false
    bat.collision_func = function(self, other)
        self:delete()
    end
    local field = shademan:get_field()
    bat.delete_func = function(self)
        self:erase()
    end
    local same_column_query = function(c)
        return not c:is_deleted() and c:get_team() ~= bat:get_team() and c:get_tile():x() == bat:get_tile():x() and c:get_tile():y() ~= bat:get_tile():y()
    end
    local has_turned = false
    bat.update_func = function(self, dt)
        self:get_tile():attack_entities(self)
        self:get_tile():highlight(Highlight.Solid)
        if self:get_current_tile():is_edge() and self.slide_started and not self:is_deleted() then 
            self:delete()
        end
        if self:is_deleted() then return end
        if self:is_sliding() == false then
            local dest = self:get_tile(direction, 1)
			if #field:find_characters(same_column_query) > 0 and not has_turned then
                local target = field:find_characters(same_column_query)[1]
                if target:get_tile():y() < self:get_tile():y() then
                    direction = Direction.Up
                else
                    direction = Direction.Down
                end
                dest = self:get_tile(direction, 1)
                has_turned = true
            end
            local ref = self
            self:slide(dest, frames(24), frames(0), ActionOrder.Voluntary, function()
                ref.slide_started = true 
            end)
        end
    end
    bat.can_move_to_func = function(tile)
        return true
    end
    return bat
end

function find_best_target(plane)
    local target = plane:get_target()
    local field = plane:get_field()
    local query = function(c)
        return c:get_team() ~= plane:get_team()
    end
    local potential_threats = field:find_characters(query)
    local goal_hp = 99999
    if #potential_threats > 0 then
        for i = 1, #potential_threats, 1 do
            local possible_target = potential_threats[i]
            if possible_target:get_health() <= goal_hp and possible_target:get_health() > 0 then
                target = possible_target
            end
        end
    end
    return target
end

function package_init(self)
    --meta
    self:set_name("Shademan")
    self:set_health(1000)
    self:set_texture(Engine.load_texture(_modpath.."shademan.png"))
    local anim = self:get_animation()
    local previous_tile = nil
    anim:load(_modpath.."shademan.animation")
    anim:set_state("0")
    anim:set_playback(Playback.Loop)
    anim:refresh(self:sprite())
    self:set_float_shoe(true)
    self:set_air_shoe(true)
    local move_count = 1
    local goal_move_count = 3
    local teleport_cooldown_list = {36, 18, 18}
    local current_move_timer = 0
    local set_field_once = true
    local field = nil
    local should_attack = false
    local should_move = true
    local warp_tile = nil
    local last_attack = nil
    local current_tile = nil
    self:register_status_callback(Hit.Flinch, function()
        anim:set_state("1")
        anim:on_complete(function()
            anim:set_state("0")
            anim:set_playback(Playback.Loop)
        end)
    end)
    local frame1 = {1, 1/60}
    local long_frames = make_frame_data(
        {
            frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1,
            frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1,
            frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1,
            frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1, frame1
        }
    )
    local target = nil
    self.on_spawn_func = function(self)
        warp_tile = self:get_tile()
        field = self:get_field()
        previous_tile = self:get_tile()
        target = self:get_target()
        current_tile = self:get_tile()
    end
    self.on_countered_func = function()
        self:set_facing(previous_tile:get_facing())
        self:teleport(previous_tile, ActionOrder.Immediate, nil)
    end
    local tile_array = {}
    local occupied_query = function(ent)
        return Battle.Obstacle.from(ent) ~= nil and ent:get_name() ~= "Bat" or Battle.Character.from(ent) ~= nil
    end
    self.can_move_to_func = function(tile)
        return tile and not tile:is_edge() and #tile:find_entities(occupied_query) == 0
    end
    self.update_func = function(self, dt)
        if should_move then
            if current_move_timer >= teleport_cooldown_list[move_count] then
                current_move_timer = 0
                if move_count < goal_move_count then
                    if set_field_once then
                        target = find_best_target(self)
                        tile_array = {}
                        for i = 1, 6, 1 do
                            for j = 1, 3, 1 do
                                local tile = field:tile_at(i, j)
                                if self.can_move_to_func(tile) and self:is_team(tile:get_team()) and tile ~= self:get_tile() then
                                    table.insert(tile_array, tile)
                                end
                            end
                        end
                        set_field_once = false
                    end
                    if anim:get_state() == "0" then
                        warp_tile = tile_array[math.random(1, #tile_array)]
                        set_field_once = true
                        anim:set_state("4")
                        previous_tile = self:get_tile()
                        anim:on_complete(function()
                            if warp_tile:get_team() ~= self:get_team() then
                                if self:get_tile():x() < target:get_tile():x() then
                                    self:set_facing(Direction.Left)
                                else
                                    self:set_facing(Direction.Right)
                                end
                            else
                                self:set_facing(warp_tile:get_facing())
                            end
                            self:teleport(warp_tile, ActionOrder.Immediate, function()
                                anim:set_state("3")
                                move_count = move_count + 1
                                anim:on_complete(function()
                                    anim:set_state("0")
                                    anim:set_playback(Playback.Loop)
                                end)
                            end)
                        end)
                    end
                else
                    move_count = 1
                    should_move = false
                    should_attack = true
                end
            else
                current_move_timer = current_move_timer + 1
            end
        elseif should_attack then
            if last_attack ~= "Bat Attack" then
                anim:set_state("5")
                anim:on_complete(function()
                    anim:set_state("6")
                    local tile_direction_list = {Direction.Up, self:get_facing(), Direction.Down, Direction.join(self:get_facing(), Direction.Up), Direction.join(self:get_facing(), Direction.Down)}
                    local bat_tile_array = {}
                    local bat_count = 0
                    for i = 1, #tile_direction_list, 1 do
                        local prospective_tile = self:get_tile(tile_direction_list[i], 1)
                        if #prospective_tile:find_entities(occupied_query) == 0 and not prospective_tile:is_edge() then
                            table.insert(bat_tile_array, prospective_tile)
                            bat_count = bat_count + 1
                            if bat_count >= 3 then
                                break
                            end
                        end
                    end
                    for t = 1, #bat_tile_array, 1 do
                        local bat_tile = bat_tile_array[t]
                        local bat = spawn_bat(self)
                        local fx = Battle.ParticlePoof.new()
                        field:spawn(fx, bat_tile)
                        field:spawn(bat, bat_tile)
                    end
                    anim:set_state("7")
                    anim:on_complete(function()
                        anim:set_state("0")
                        anim:set_playback(Playback.Loop)
                    end)
                end)
                last_attack = "Bat Attack"
                should_attack = false
                should_move = true
                set_field_once = true
                move_count = 1
            elseif last_attack == "Bat Attack" and should_attack then
                local target = find_best_target(self)
                if target and not target:is_team(target:get_tile(target:get_facing(), 1):get_team()) then
                    local target_tile_list = {
                        target:get_tile(target:get_facing(), 1),
                        target:get_tile(Direction.join(target:get_facing(), Direction.Up), 1),
                        target:get_tile(Direction.join(target:get_facing(), Direction.Down), 1),
                        target:get_tile(target:get_facing_away(), 1),
                        target:get_tile(Direction.join(target:get_facing_away(), Direction.Up), 1),
                        target:get_tile(Direction.join(target:get_facing_away(), Direction.Down), 1)
                    }
                    local target_tile = nil
                    for i = 1, #target_tile_list, 1 do
                        if self.can_move_to_func(target_tile_list[i]) and target_tile_list[i]:get_tile(self:get_facing_away(), 1):get_team() == self:get_team() then
                            target_tile = target_tile_list[i]
                            break
                        end
                    end
                    if target_tile ~= nil then
                        anim:set_state("4")
                        previous_tile = self:get_tile()
                        anim:on_complete(function()
                            if target_tile:get_team() ~= self:get_team() then
                                target = find_best_target(self)
                                if self:get_tile():x() < target:get_tile():x() then
                                    self:set_facing(Direction.Left)
                                else
                                    self:set_facing(Direction.Right)
                                end
                            else
                                self:set_facing(target_tile:get_facing())
                            end
                            self:teleport(target_tile, ActionOrder.Immediate, function()
                                anim:set_state("3")
                                anim:on_complete(function()
                                    anim:set_state("8")
                                    self:toggle_counter(true)
                                    anim:on_complete(function()
                                        local action = Battle.CardAction.new(self, "9")
                                        local spell = Battle.Spell.new(self:get_team())
                                        action.execute_func = function(act, user)
                                            spell:highlight_tile(Highlight.Flash)
                                            local spell_tile = self:get_tile(self:get_facing(), 1)
                                            local spell_once = true
                                            spell.collision_func = function(self, other)
                                                self:delete()
                                            end
                                            spell:set_hit_props(
                                                HitProps.new(
                                                    180,
                                                    Hit.Impact | Hit.Flash | Hit.Flinch,
                                                    Element.None,
                                                    self:get_context(),
                                                    Drag.None
                                                )
                                            )
                                            local copytile1 = spell_tile:get_tile(Direction.Up, 1)
                                            local copybox1 = Battle.SharedHitbox.new(spell, 0.099)
                                            copybox1:set_hit_props(spell:copy_hit_props())
                                            local copybox2 = Battle.SharedHitbox.new(spell, 0.099)
                                            copybox2:set_hit_props(spell:copy_hit_props())
                                            local copytile2 = spell_tile:get_tile(Direction.Down, 1)
                                            spell.update_func = function(self, dt)
                                                self:get_tile():attack_entities(self)
                                                if spell_once then
                                                    spell_once = false
                                                    if copytile1 and not copytile1:is_edge() then
                                                        copytile1:highlight(Highlight.Flash)
                                                        field:spawn(copybox1, copytile1)
                                                    end
                                                    if copytile2 and not copytile2:is_edge() then
                                                        copytile2:highlight(Highlight.Flash)
                                                        field:spawn(copybox2, copytile2)
                                                    end
                                                end
                                            end
                                            act:add_anim_action(2, function()
                                                field:spawn(spell, spell_tile)
                                            end)
                                            act:add_anim_action(3, function()
                                                self:toggle_counter(false)
                                            end)
                                            spell.delete_func = function(self)
                                                if self and not self:is_deleted() then self:erase() end
                                                if copybox1 and not copybox1:is_deleted() then
                                                    copybox1:erase()
                                                end
                                                if copybox2 and not copybox2:is_deleted() then
                                                    copybox2:erase()
                                                end
                                                copytile1:highlight(Highlight.None)
                                                copytile2:highlight(Highlight.None)
                                            end
                                        end
                                        action.action_end_func = function(act)
                                            if not spell:is_deleted() then spell:delete() end
                                            anim:set_state("0")
                                            anim:set_playback(Playback.Loop)
                                        end
                                        self:card_action_event(action, ActionOrder.Involuntary)
                                    end)
                                end)
                            end)
                        end)
                        last_attack = "Claw Swipe"
                        should_attack = false
                        should_move = true
                        set_field_once = true
                        move_count = 1
                    end
                elseif target and target:is_team(target:get_tile(target:get_facing(), 1):get_team()) then
                    local target_tile_list = {
                        target:get_tile(target:get_facing(), 2),
                        target:get_tile(target:get_facing_away(), 2)
                    }
                    local target_tile = nil
                    for i = 1, #target_tile_list, 1 do
                        if self.can_move_to_func(target_tile_list[i]) then
                            target_tile = target_tile_list[i]
                            break
                        end
                    end
                    if target_tile ~= nil then
                        anim:set_state("4")
                        previous_tile = self:get_tile()
                        anim:on_complete(function()
                            if target_tile:get_team() ~= self:get_team() then
                                target = find_best_target(self)
                                if self:get_tile():x() > target:get_tile():x() then
                                    self:set_facing(Direction.Left)
                                else
                                    self:set_facing(Direction.Right)
                                end
                            else
                                self:set_facing(target_tile:get_facing())
                            end
                            self:teleport(target_tile, ActionOrder.Immediate, function()
                                anim:set_state("3")
                                anim:on_complete(function()
                                    anim:set_state("5")
                                    self:toggle_counter(true)
                                    anim:on_complete(function()
                                        local noise_crush = create_noise_crush(self)
                                        local noise_fx = Battle.Artifact.new()
                                        noise_fx:set_facing(self:get_facing())
                                        noise_fx:set_texture(self:get_texture())
                                        noise_fx:sprite():set_layer(-2)
                                        local noise_fx_anim = noise_fx:get_animation()
                                        noise_fx_anim:copy_from(self:get_animation())
                                        noise_fx_anim:set_state("11")
                                        noise_fx_anim:refresh(noise_fx:sprite())
                                        noise_fx_anim:set_playback(Playback.Loop)
                                        local action = Battle.CardAction.new(self, "6")
                                        action:override_animation_frames(long_frames)
                                        action:set_lockout(make_animation_lockout())
                                        self:toggle_counter(false)
                                        action.execute_func = function(act, user)
                                            act:add_anim_action(1, function()
                                                field:spawn(noise_crush, self:get_tile(self:get_facing(), 1))
                                            end)
                                            act:add_anim_action(16, function()
                                                field:spawn(noise_fx, self:get_tile(self:get_facing(), 1))
                                            end)
                                        end
                                        action.action_end_func = function(act)
                                            if not noise_crush:is_deleted() then noise_crush:delete() end
                                            noise_fx:erase()
                                            anim:set_state("7")
                                            anim:on_complete(function()
                                                anim:set_state("0")
                                                anim:set_playback(Playback.Loop)
                                            end)
                                        end
                                        self:card_action_event(action, ActionOrder.Involuntary)
                                    end)
                                end)
                            end)
                        end)
                    end
                    last_attack = "Noise Crush"
                    should_attack = false
                    should_move = true
                    set_field_once = true
                    move_count = 1
                    --teleport two tiles away from the target regardless of who owns the tile.
                    --use elec pulse 1 but with the animations built into the Shademan files.
                end
            end
        end
    end
end