local noop = function () end
local texture = nil
local shot_texture = nil
local shot_animation = nil
local animation_path = nil
local pew = nil

local boom_sound = Engine.load_audio(_modpath.."boom.ogg")
local boom_texture = Engine.load_texture(_modpath.."spell_explosion.png")
local boom_anim = _modpath.."spell_explosion.animation"

function get_endloop_tile(plane)
    local field = plane:get_field()
    local y = plane:get_tile():y()
    if plane:get_rank() ~= Rank.V1 then
        local target = find_best_target(plane)
        if target and not target:is_deleted() then y = target:get_tile():y() end
    end
    local dest = field:tile_at(7, tonumber(y))
    if plane:get_facing() == Direction.Right then
        dest = field:tile_at(0, tonumber(y))
    end
    plane._is_looping = true
    return dest
end

function find_best_target(plane)
    local target = plane:get_target()
    local field = plane:get_field()
    local query = function(c)
        return c:get_team() ~= plane:get_team()
    end
    local potential_threats = field:find_characters(query)
    local goal_hp = 100
    if #potential_threats > 0 then
        for i = 1, #potential_threats, 1 do
            local possible_target = potential_threats[i]
            if possible_target:get_health() <= goal_hp then
                target = possible_target
            end
        end
    end
    return target
end

function create_attack(plane)
    local spell = Battle.Spell.new(plane:get_team())
    spell:highlight_tile(Highlight.Flash)
    spell:set_hit_props(
        HitProps.new(
            plane._attack,
            Hit.Flinch | Hit.Impact,
            Element.None,
            plane:get_context(),
            Drag.None
        )
    )
    local do_once = true
    local field = plane:get_field()
    local flash_before_strike = math.min(10, math.floor(plane._count_between_attack_sends/2))
    spell.update_func = function(self, dt)
        if flash_before_strike <= 0 then
            self:get_tile():attack_entities(self)
            if do_once then
                do_once = false
                local blast_fx = Battle.Artifact.new()
                blast_fx:set_texture(shot_texture)
                local blast_anim = blast_fx:get_animation()
                blast_anim:load(shot_animation)
                blast_anim:set_state("DEFAULT")
                blast_fx:sprite():set_layer(-2)
                blast_anim:on_complete(function()
                    blast_fx:erase()
                    self:erase()
                end)
                field:spawn(blast_fx, self:get_tile())
            end
        else
            flash_before_strike = flash_before_strike - 1
        end
    end
    Engine.play_audio(pew, AudioPriority.Low)
    return spell
end

function package_init(plane)
	if not texture then
		texture = Engine.load_texture(_modpath .. "FighterPlane.greyscaled.png")
        shot_texture = Engine.load_texture(_modpath .. "burst.png")
        shot_animation = _modpath .. "explosion.animation"
		animation_path = _modpath .. "FighterPlane.animation"
        pew = Engine.load_audio(_modpath.."gun.ogg")
	end

	-- private variables
    plane._is_looping = false
	plane._should_shoot = true
    plane._should_move = true
    plane._has_risen = false
    plane._is_attacking = false
    plane._delay_before_move = 0
    plane._target_height = -80
    plane._current_move_delay = 0
    plane._tile_slide_speed = 0
	plane._count_between_attack_sends = 0
	plane._attack = 0
    plane._movement_loops = 2
    plane._count_between_attack_sends = 0
    plane._current_attack_delay = 0
    plane._hover_before_lowering = 30
    plane._obstacle_slide_goal_x = -40
    plane._obstacle_slide_movement_x = -4
    plane._attack_range = {}
    plane._original_tile = nil
    plane._toggle_hitbox = true
    plane._stop_shooting_once = true
    plane._spawned_hitbox = false
    plane._do_once = true
    plane._nm_track_once = true
    plane._nm_divebomb_tile = nil
    
	-- meta
    plane:set_name("FgtrPlne")
	plane:set_height(45)
	plane:set_texture(texture, true)
	local rank = plane:get_rank()
	if rank == Rank.V1 then
		plane:set_health(140)
		plane._attack = 20
        plane._delay_before_move = 90
        plane._tile_slide_speed = 30
        plane._count_between_attack_sends = 20
		plane:set_palette(Engine.load_texture(_modpath.."plane_v1.pallet.png"))
	elseif rank == Rank.V2 then
		plane:set_health(180)
		plane._attack = 40
        plane._delay_before_move = 75
        plane._tile_slide_speed = 25
        plane._count_between_attack_sends = 15
		plane:set_palette(Engine.load_texture(_modpath.."plane_v2.pallet.png"))
	elseif rank == Rank.V3 then
		plane:set_health(250)
		plane._attack = 60
        plane._delay_before_move = 60
        plane._tile_slide_speed = 20
        plane._count_between_attack_sends = 10
		plane:set_palette(Engine.load_texture(_modpath.."plane_v3.pallet.png"))
    elseif rank == Rank.SP then
		plane:set_health(310)
		plane._attack = 100
        plane._delay_before_move = 45
        plane._tile_slide_speed = 15
        plane._count_between_attack_sends = 5
		plane:set_palette(Engine.load_texture(_modpath.."plane_sp.pallet.png"))
    elseif rank == Rank.NM then
		plane:set_health(310)
		plane._attack = 100
        plane._delay_before_move = 45
        plane._tile_slide_speed = 15
        plane._count_between_attack_sends = 5
		plane:set_palette(Engine.load_texture(_modpath.."plane_commando.pallet.png"))
	end

    --shadow
    local shadow = plane:create_node()
    shadow:set_layer(3)
    shadow:set_texture(Engine.load_texture(_modpath.."Plane Shadow.png"), true)
    shadow:set_offset(-16, -10)

	local anim = plane:get_animation()
	anim:load(animation_path)
	anim:set_state("IDLE")
	-- setup defense rules
	plane.defense = Battle.DefenseVirusBody.new() -- lua owns this need to keep it alive
	plane:add_defense_rule(plane.defense)

    plane:set_float_shoe(true)
	plane:set_air_shoe(true)

	-- setup event handlers
    local can_decrease_attack_count_loop = true
    local j = 1
    local propellor = plane:create_node()
    propellor:set_layer(-1)
    propellor:set_texture(texture, true)
    propellor:enable_parent_shader(true)
    local propellor_animation = Engine.Animation.new(animation_path)
    propellor_animation:set_state("PROPELLOR")
    propellor_animation:refresh(propellor)
    propellor_animation:set_playback(Playback.Loop)
    
    local point = plane:get_animation():point("PROPELLOR")
    propellor:set_origin(0-18, point.y+6)
    local character_query = function(c)
        return c:get_team() ~= plane:get_team()
    end
    local obstacle_query = function(o)
        return true
    end

    plane.on_spawn_func = function(self)
        self._original_tile = self:get_tile()
        if self:get_facing() == Direction.Right then
            self._obstacle_slide_goal_x = 40
            self._obstacle_slide_movement_x = 4
        end
    end
    plane.can_move_to_func = function(tile)
        return true
    end
    plane.collision_func = function(self, other)
        if Battle.Obstacle.from(other) ~= nil then
            local field = self:get_field()
            if not self:is_sliding() and self:get_tile():is_edge() and not self:is_teleporting() and not self._is_looping then
                local y = self._original_tile:y()
                local dest = field:tile_at(7, tonumber(y))
                if self:get_facing() == Direction.Right then
                    dest = field:tile_at(0, tonumber(y))
                end
                self:teleport(dest, ActionOrder.Voluntary, noop)
            end
        end
    end
    local plane_defense_rule = Battle.DefenseRule.new(100,DefenseOrder.CollisionOnly)
    plane_defense_rule.filter_statuses_func = function(statuses)
        statuses.flags = statuses.flags & ~Hit.Drag
        return statuses
    end
    plane:add_defense_rule(plane_defense_rule)
	plane.update_func = function(self, dt)
        if self:is_deleted() then return end
        propellor_animation:update(dt, propellor)
        if self:get_rank() == Rank.NM and self:get_health() <= 100 then
            if not self:is_sliding() and self:get_tile():is_edge() and not self:is_teleporting() and not self._is_looping then
                local dest = get_endloop_tile(plane)
                self:teleport(dest, ActionOrder.Voluntary, function()
                    self._spawned_hitbox = false
                    self._do_once = true
                end)
            end
            if self:get_tile() ~= self._original_tile and not self:is_sliding() then
                self:slide(self:get_tile(self:get_facing(), 1), frames(plane._tile_slide_speed), frames(1), ActionOrder.Voluntary, function()
                    self._spawned_hitbox = false
                    self._do_once = true
                    self._is_looping = false
                end)
            elseif self:get_tile() == self._original_tile and not self:is_sliding() then
                if self._do_once then
                    self._do_once = true
                end
            end
            if not self._has_risen then
                if self:get_offset().y <= self._target_height then
                    self._has_risen = true
                    anim:set_state('ATTACK')
                    anim:set_playback(Playback.Loop)
                else
                    if self._toggle_hitbox then
                        anim:set_state('ATTACK_AIM')
                        self:toggle_hitbox(false)
                        self._toggle_hitbox = false
                    end
                    self:set_offset(0.0, self:get_offset().y - 4)
                    shadow:set_offset(shadow:get_offset().x, shadow:get_offset().y + 2)
                end
            else
                local target = nil
                local target_tile = self._nm_divebomb_tile
                if self._nm_track_once then
                    target = find_best_target(self)
                    self._nm_divebomb_tile = self:get_tile(self:get_facing(), 3)
                    if target and not target:is_deleted() then
                        self._nm_divebomb_tile = target:get_tile()
                    end
                    target_tile = self._nm_divebomb_tile
                    self._nm_track_once = false
                end
                local speedy_boy = (math.abs(self._target_height*((target_tile:x() - self:get_tile():x()) + (target_tile:y() - self:get_tile():y())))/60)
                if self:get_offset().y < 0 then
                    self:set_offset(0.0, self:get_offset().y + speedy_boy)
                    shadow:set_offset(shadow:get_offset().x, shadow:get_offset().y + speedy_boy/2)
                end
                if self:get_tile() == target_tile then
                    if self._do_once then
                        local plane_blast = create_attack(self)
                        local field = self:get_field()
                        local fx = Battle.Artifact.new()
                        fx:set_texture(boom_texture, true)
                        local animation = fx:get_animation()
                        animation:load(boom_anim)
                        animation:set_state("Default")
                        animation:refresh(fx:sprite())
                        animation:on_complete(function()
                            fx:erase()
                        end)
                        field:spawn(fx, target_tile)
                        field:spawn(plane_blast, target_tile)
                        self:delete()
                        Engine.play_audio(boom_sound, AudioPriority.Low)
                    end
                else
                    self:slide(self._nm_divebomb_tile, frames(plane._tile_slide_speed), frames(1), ActionOrder.Voluntary, function() self._is_looping = false end)
                end
            end
        else
            if self._current_move_delay <= 0 then
                if self._should_shoot then
                    if self._do_once then
                        self._do_once = false
                        local field = plane:get_field()
                        plane._attack_range = {}
                        for i = 1, 6, 1 do
                            local tile = field:tile_at(i, 2)
                            local top_tile = field:tile_at(i, 2):get_tile(Direction.Up, 1)
                            local bottom_tile = field:tile_at(i, 2):get_tile(Direction.Down, 1)
                            local team = self:get_team()
                            if tile and not tile:is_edge() and tile:get_team() ~= team or top_tile and not top_tile:is_edge() and top_tile:get_team() ~= team or bottom_tile and not bottom_tile:is_edge() and bottom_tile:get_team() ~= team then
                                if tile:x() > self:get_tile():x() and self:get_facing() == Direction.Right or tile:x() < self:get_tile():x() and self:get_facing() == Direction.Left then
                                    if i % 2 == 0 then
                                        table.insert(plane._attack_range, tile:get_tile(Direction.Up, 1))
                                        table.insert(plane._attack_range, tile)
                                        table.insert(plane._attack_range, tile:get_tile(Direction.Down, 1))
                                    else
                                        table.insert(plane._attack_range, tile:get_tile(Direction.Down, 1))
                                        table.insert(plane._attack_range, tile)
                                        table.insert(plane._attack_range, tile:get_tile(Direction.Up, 1))
                                    end
                                end
                            end
                        end
                        if self:get_rank() == Rank.NM then
                            local n = #self._attack_range
                            for m = n, 1, -1 do
                                table.insert(self._attack_range, self._attack_range[m])
                            end
                        end
                        if plane:get_facing() == Direction.Right then
                            j = 1
                        else
                            j = #plane._attack_range
                        end
                    end
                    if self:get_rank() == Rank.V1 and not self._has_risen then
                        self._has_risen = true
                        anim:set_state('ATTACK')
                        anim:set_playback(Playback.Loop)
                    end
                    if not self._has_risen then
                        if self:get_offset().y <= self._target_height then
                            self._has_risen = true
                            anim:set_state('ATTACK')
                            anim:set_playback(Playback.Loop)
                        else
                            if self._toggle_hitbox then
                                anim:set_state('ATTACK_AIM')
                                self:toggle_hitbox(false)
                                self._toggle_hitbox = false
                            end
                            self:set_offset(0.0, self:get_offset().y - 2)
                            shadow:set_offset(shadow:get_offset().x, shadow:get_offset().y + 1)
                        end
                    else
                        local field = self:get_field()
                        if j == #self._attack_range and plane:get_facing() == Direction.Right or j == 0 and self:get_facing() == Direction.Left then
                            if self._stop_shooting_once then
                                self._stop_shooting_once = false
                                anim:set_state('ATTACK_AIM')
                                anim:set_playback(Playback.Reverse)
                                anim:on_complete(function()
                                    anim:set_state('IDLE')
                                    anim:set_playback(Playback.Loop)
                                end)
                            end
                            if self._hover_before_lowering <= 0 then
                                if self:get_offset().y < 0 then
                                    self:set_offset(0.0, self:get_offset().y + 2)
                                    shadow:set_offset(shadow:get_offset().x, shadow:get_offset().y - 1)
                                else
                                    self:toggle_hitbox(true)
                                    self._toggle_hitbox = true
                                    self._should_shoot = false
                                    self._should_move = true
                                    self._hover_before_lowering = 30
                                    self._has_risen = false
                                    self._current_attack_delay = self._count_between_attack_sends
                                    self._current_move_delay = self._delay_before_move
                                end
                            else
                                self._hover_before_lowering = self._hover_before_lowering - 1
                            end
                        else
                            if self._current_attack_delay <= 0 then
                                local plane_blast = create_attack(self)
                                field:spawn(plane_blast, self._attack_range[j])
                                self._current_attack_delay = self._count_between_attack_sends
                                if self:get_facing() == Direction.Right then
                                    j = j + 1
                                else
                                    j = j - 1
                                end
                            else
                                self._current_attack_delay = self._current_attack_delay - 1
                            end
                        end
                    end
                elseif self._should_move then
                    if #self:get_tile():find_characters(character_query) > 0 and not self._spawned_hitbox then
                        local hitbox = Battle.Hitbox.new(self:get_team())
                        hitbox:set_hit_props(
                            HitProps.new(
                                50,
                                Hit.Flinch | Hit.Impact | Hit.Flash,
                                Element.None,
                                plane:get_context(),
                                Drag.None
                            )
                        )
                        self:get_field():spawn(hitbox, self:get_tile())
                        self._spawned_hitbox = true
                    end
                    if self._movement_loops > 0 then
                        if not self:is_sliding() and self:get_tile():is_edge() and not self:is_teleporting() and not self._is_looping then
                            local dest = get_endloop_tile(plane)
                            self:teleport(dest, ActionOrder.Voluntary, function() plane._movement_loops = plane._movement_loops - 1 end)
                        else
                            local dest = self:get_tile(self:get_facing(), 1)
                            if dest and #dest:find_obstacles(obstacle_query) > 0 and not self:is_sliding() and not self:is_teleporting()then
                                dest = get_endloop_tile(plane)
                                if self:get_offset().x ~= self._obstacle_slide_goal_x then
                                    self:set_offset(self:get_offset().x + self._obstacle_slide_goal_x/self._tile_slide_speed, 0.0)
                                else
                                    self:teleport(dest, ActionOrder.Voluntary, function()
                                        self:set_offset(0.0, 0.0)
                                        self._movement_loops = 0
                                        self._spawned_hitbox = false
                                    end)
                                end
                            else
                                self:slide(self:get_tile(self:get_facing(), 1), frames(plane._tile_slide_speed), frames(1), ActionOrder.Voluntary, function()
                                    self._is_looping = false
                                    self._spawned_hitbox = false
                                end)
                            end
                        end
                    else
                        if not self:is_sliding() and self:get_tile():is_edge() and not self:is_teleporting() and not self._is_looping then
                            local dest = get_endloop_tile(plane)
                            self:teleport(dest, ActionOrder.Voluntary, function() self._spawned_hitbox = false end)
                        end
                        if self:get_tile() ~= self._original_tile then
                            self:slide(self:get_tile(self:get_facing(), 1), frames(plane._tile_slide_speed), frames(1), ActionOrder.Voluntary, function()
                                self._is_looping = false
                                self._spawned_hitbox = false
                            end)
                        else
                            self._should_move = false
                            self._should_shoot = true
                            self._has_risen = false
                            self._stop_shooting_once = true
                            self._movement_loops = 2
                            self._do_once = true
                        end
                    end
                end
            else
                self._current_move_delay = self._current_move_delay - 1
            end
        end
    end
	plane.battle_start_func = noop
	plane.battle_end_func = noop
	plane.delete_func = noop
end