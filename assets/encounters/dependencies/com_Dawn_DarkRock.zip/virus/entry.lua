local Cannon = include("Chips/Cannon/entry.lua")
local HiCannon = include("Chips/HiCannon/entry.lua")
local MCannon = include("Chips/MCannon/entry.lua")
local MoonBld = include("Chips/MoonBld/entry.lua")
local Tornado = include("Chips/Tornado/entry.lua")
local AirHocky = include("Chips/AirHocky/entry.lua")
local WideSwrd = include("Chips/WideSwrd/entry.lua")
local LongSwrd = include("Chips/LongSwrd/entry.lua")
local DarkSwrd = include("Chips/DrkSword/entry.lua")
local SuprVulc = include("Chips/SuperVulc/vulcan/vulcan.lua")
local MiniBomb = include("Chips/MiniBomb/bomb/bomb.lua")
local EnergBom = include("Chips/EnergBom/bomb/bomb.lua")
local MegEnBom = include("Chips/MegEnBom/bomb/bomb.lua")
local FireSwrd = include("Chips/FireSwrd/entry.lua")
local AquaSwrd = include("Chips/AquaSwrd/entry.lua")
local BambSwrd = include("Chips/BambSwrd/entry.lua")
local ElecSwrd = include("Chips/ElecSwrd/entry.lua")
local FireBrn2 = include("Chips/FireBurn2/entry.lua")
local FireBrn3 = include("Chips/FireBurn3/entry.lua")
local GunDelHel = include("Chips/GunDelHell/entry.lua")
local DarkHockey = include("Chips/WildRide/entry.lua")
local KnifeSpam = include("Chips/KnifeSpam/entry.lua")
local PiercingCannon = include("Chips/DarkCannonPiercing/entry.lua")

local function spawn_mob_move(dark_rock)
    local fx = Battle.Artifact.new()
    fx:set_texture(Engine.load_texture(_modpath.."mob_move.png", true))
    local anim = fx:get_animation()
    anim:load(_modpath.."mob_move.animation")
    anim:set_state("DEFAULT")
    anim:refresh(fx:sprite())
    anim:on_complete(function()
        fx:erase()
    end)
    local field = dark_rock:get_field()
    field:spawn(fx, dark_rock:get_tile())
end

local function find_best_target(plane)
    local target = plane:get_target()
    local field = plane:get_field()
    local query = function(c)
        return c:get_team() ~= plane:get_team()
    end
    local potential_threats = field:find_characters(query)
    local goal_hp = 9999
    if #potential_threats > 0 then
        for i = 1, #potential_threats, 1 do
            local possible_target = potential_threats[i]
            if possible_target:get_health() <= goal_hp then
                target = possible_target
            end
        end
    end
    return target
end

local function move_at_random(self)
	local current_tile = self:get_tile()
	local field = self:get_field()
	local target_tile_x = math.floor(math.random(6))
	local target_tile_y = math.floor(math.random(3))
	local target_tile = nil
	local dummy_tile = nil
	local is_occupied = function(ent)
		if Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil then
			return true
		end
	end
    local tile_array = {}
    for x = 1, 6, 1 do
        for y = 1, 3, 1 do
            local prospective_tile = field:tile_at(x, y)
            if prospective_tile and not prospective_tile:is_edge() and not prospective_tile:is_reserved({self:get_id()}) and #prospective_tile:find_entities(is_occupied) == 0 then
                if self:is_team(prospective_tile:get_team()) then
                    table.insert(tile_array, prospective_tile)
                end
            end
        end
    end
    if #tile_array == 0 then return false end
	target_tile = tile_array[math.random(1, #tile_array)]
	if target_tile then
		moved = self:teleport(target_tile, ActionOrder.Immediate, function()
            spawn_mob_move(self)
            self._teleports = self._teleports + 1
            if self._teleports >= self._goal_teleports then
                self._teleports = 0
                self._goal_teleports = math.random(3, 5)
                self._should_attack = true
                self._should_move = false
            end
        end)
		if moved then
			self._movement_wait = 15
            self._current_attacks = 0
		end
	end
	return moved
end

local function buster_spam_action(dark_rock)
    local spell = Battle.Spell.new(dark_rock:get_team())
    spell.slide_started = false
    spell:set_facing(dark_rock:get_facing())
    local damage = 10
    spell:set_hit_props(
        HitProps.new(
            damage,
            Hit.Impact,
            Element.None,
            dark_rock:get_context(),
            Drag.None
        )
    )
    spell.update_func = function(self, dt) 
        self:get_current_tile():attack_entities(self)
        if self:is_sliding() == false then
            if self:get_current_tile():is_edge() and self.slide_started then 
                self:delete()
            end 
			
            local dest = self:get_tile(spell:get_facing(), 1)
            local ref = self
            self:slide(dest, frames(1), frames(0), ActionOrder.Voluntary, 
                function()
                    ref.slide_started = true 
                end
            )
        end
    end
    spell.collision_func = function(self, other)
		self:delete()
	end
    spell.attack_func = function(self, other) 
    end

    spell.delete_func = function(self)
		self:erase()
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    Engine.play_audio(AudioType.BusterPea, AudioPriority.Low)
    return spell
end

function package_init(self)
    --meta
    self:set_name("Dark Rock")
    self:set_health(1000)
    self:set_texture(Engine.load_texture(_modpath.."navi_megaman_atlas.og.png"))

    local anim = self:get_animation()
    anim:load(_modpath.."megaman.animation")
    anim:set_state("PLAYER_IDLE")
    local DarkDefense = Battle.DefenseRule.new(2,DefenseOrder.CollisionOnly)
    DarkDefense.filter_statuses_func = function(statuses)
        statuses.flags = statuses.flags & ~Hit.Blind
        statuses.flags = statuses.flags & ~Hit.Freeze
        statuses.flags = statuses.flags & ~Hit.Flash
        statuses.flags = statuses.flags & ~Hit.Flinch
        return statuses
    end
    self._movement_wait = 10
    self._should_move = true
    self._should_attack = false
    local attack_list = {
        {Cannon, MiniBomb, WideSwrd},
        {Cannon, WideSwrd, EnergBom},
        {Cannon, LongSwrd, MegEnBom},
        {FireSwrd, FireBrn2}, --[[ TankCan1,--]]
        {MCannon, AquaSwrd},  --[[ TrnArrw2,--]]
        {ElecSwrd}, --[[ TankCan2,--]] --[[ DolThdr2,--]]
        {GunDelHel, BambSwrd}, --[[ RlngLog2,--]]
        {Tornado, MoonBld}, --[[ TankCan3,--]] 
        {AirHocky, DarkSwrd}, --[[ TankCan3,--]] 
        {SuprVulc, DarkSwrd, FireBrn3} --[[ TrnArrw3,--]] --[[ DolThdr3,--]] --[[ RlngLog3,--]] 
    }
    local attack_list_index = 10
    local pick_attack_once = true
    local chosen_attack = nil
    local buster_spam_cooldown = 4
    local current_spam_counter = 0
    local roll = -1
    local roll_once = true
    local frame1 = {1, 0.05}
    local frame2 = {2, 0.05}
    local frame3 = {3, 0.05}
    local frame4 = {1, 0.05}
    local frame5 = {2, 0.05}
    local frame6 = {3, 0.05}
    local frame7 = {1, 0.05}
    local frame8 = {2, 0.05}
    local frame9 = {3, 0.05}
    local frame10 = {4, 0.1}
    local frame_sequence = make_frame_data({frame1, frame2, frame3, frame4, frame5, frame6, frame7, frame8, frame9, frame10})
    local health = 1000
    local tile_array = {}
    local do_once = true
    self._teleports = 0
    self._goal_teleports = 3
    local current_attacks = 0
    self:register_status_callback(Hit.Drag, function()
        self._should_attack = true
        self._should_move = false
        roll = -1
        roll_once = true
        pick_attack_once = true
    end)
    self:register_status_callback(Hit.Stun, function()
        self._should_attack = true
        self._should_move = false
        roll = -1
        roll_once = true
        pick_attack_once = true
    end)
    self:set_float_shoe(true)
    local entity_query = function(ent)
        return Battle.Obstacle.from(ent) ~= nil or Battle.Character.from(ent) ~= nil
    end
    self.can_move_to_func = function(tile)
        return tile and tile:is_walkable() and not tile:is_edge() and self:is_team(tile:get_team()) and #tile:find_entities(entity_query) == 0
    end
    local idle_counter = 0
    self.update_func = function(self, dt)
        if self:get_health() ~= health then
            attack_list_index = math.max(1, math.floor(self:get_health() / 100))
        end
        if self._should_attack and anim:get_state() == "PLAYER_IDLE" then
            idle_counter = idle_counter + 1
            if idle_counter >= 30 then
                if current_attacks >= 3 then
                    self._should_attack = false
                    self._should_move = true
                end
                roll = -1
                roll_once = true
                pick_attack_once = true
                idle_counter = 0                
            end
            if roll_once then
                roll = math.random(1, 20)
                roll_once = false
            end
            if roll > 5 then
                if pick_attack_once then
                    pick_attack_once = false
                    chosen_attack = attack_list[attack_list_index][math.random(1, #attack_list[attack_list_index])]
                    current_attacks = current_attacks + 1
                    local movement = false
                    local action = chosen_attack.card_create_action(self)
                    self:card_action_event(action, ActionOrder.Involuntary)
                    if math.random(1, 20) > 10 then
                        self._should_attack = false
                        self._should_move = true
                    end
                    roll = -1
                end
            else
                if pick_attack_once then
                    local action = Battle.CardAction.new(self, "PLAYER_SHOOTING")
                    action:override_animation_frames(frame_sequence)
                    action:set_lockout(make_animation_lockout())
                    action.execute_func = function(act, user)
                        local buster = act:add_attachment("BUSTER")
                        local sprite = buster:sprite()
                        sprite:set_texture(self:get_texture())
                        sprite:enable_parent_shader(true)
                        sprite:set_layer(-1)

                        local buster_anim = buster:get_animation()
                        buster_anim:copy_from(self:get_animation())
                        buster_anim:set_state("BUSTER")
                        buster_anim:refresh(sprite)
                        act:add_anim_action(1, function()
                            local flare = buster:add_attachment("endpoint")
                            local flare_sprite = flare:sprite()
                            flare_sprite:set_texture(Engine.load_texture(_modpath.."pew.png", true))
                            flare_sprite:set_layer(-1)

                            local flare_anim = flare:get_animation()
                            flare_anim:load(_modpath.."pew.animation")
                            flare_anim:set_state("0")
                            flare_anim:refresh(flare_sprite)
                            flare_anim:on_complete(function()
                                flare_sprite:hide()
                            end)
                            local spell = buster_spam_action(self)
                            self:get_field():spawn(spell, self:get_tile(self:get_facing(), 1))
                        end)
                        act:add_anim_action(4, function()
                            local flare = buster:add_attachment("endpoint")
                            local flare_sprite = flare:sprite()
                            flare_sprite:set_texture(Engine.load_texture(_modpath.."pew.png", true))
                            flare_sprite:set_layer(-1)

                            local flare_anim = flare:get_animation()
                            flare_anim:load(_modpath.."pew.animation")
                            flare_anim:set_state("0")
                            flare_anim:refresh(flare_sprite)
                            flare_anim:on_complete(function()
                                flare_sprite:hide()
                            end)
                            local spell = buster_spam_action(self)
                            self:get_field():spawn(spell, self:get_tile(self:get_facing(), 1))
                        end)
                        act:add_anim_action(7, function()
                            local flare = buster:add_attachment("endpoint")
                            local flare_sprite = flare:sprite()
                            flare_sprite:set_texture(Engine.load_texture(_modpath.."pew.png", true))
                            flare_sprite:set_layer(-1)

                            local flare_anim = flare:get_animation()
                            flare_anim:load(_modpath.."pew.animation")
                            flare_anim:set_state("0")
                            flare_anim:refresh(flare_sprite)
                            flare_anim:on_complete(function()
                                flare_sprite:hide()
                            end)
                            local spell = buster_spam_action(self)
                            self:get_field():spawn(spell, self:get_tile(self:get_facing(), 1))
                        end)
                    end
                    action.action_end_func = function(self)
                        self._should_attack = false
                        self._should_move = true
                        roll = -1
                        current_attacks = current_attacks + 1
                    end
                    self:card_action_event(action, ActionOrder.Involuntary)
                    current_spam_counter = buster_spam_cooldown
                    pick_attack_once = false
                end
            end
        elseif self._should_move then
            if self._movement_wait <= 0 then
                if not self:is_teleporting() then
                    move_at_random(self)
                end
            else
                self._movement_wait = self._movement_wait - 1
            end
        end
    end
end