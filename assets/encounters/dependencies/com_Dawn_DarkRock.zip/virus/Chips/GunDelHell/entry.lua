local chip = {name="GunDelHel"}

nonce = function() end

local gunhilt = Engine.load_texture(_folderpath .. "gunhilt.png")
local sunray = Engine.load_texture(_folderpath .. "sun_ray.png")

function package_init(package)

    package:declare_package_id("GunDelHel.Rune.chip.PVP")
    package:set_icon_texture(Engine.load_texture(_folderpath .. "icon.png"))
    package:set_preview_texture(Engine.load_texture(_folderpath .. "preview.png"))
    package:set_codes({ 'G', 'D', 'H'})

    local props = package:get_card_props()
    props.shortname = "GunDelHel"
    props.time_freeze = false
    props.element = Element.None
    props.limit = 1
    props.card_class = CardClass.Dark
    props.can_boost = false
    props.description = "Hits row 2pnl ahd w/drkmatr"

end

chip.card_create_action = function(actor)
    local STARTUP = { 1, 0.1 } -- Wait 6 frames, yes I counted again and it sounds like you got it
    local THE_REST = { 1, 2.23 } -- Stay posed for 134 frames.

    local FRAMES = make_frame_data({ STARTUP, THE_REST })

    local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
    action:set_lockout(make_animation_lockout())

    action:override_animation_frames(FRAMES)

    action.execute_func = function(self, user)


        local component = Battle.Component.new(user, Lifetimes.Local)
        local prev_panel = user:get_current_tile()
        local randomNumber = nil
        local tile_state = nil

        component.update_func = function(self)
            if user:get_current_tile() ~= prev_panel then 
                prev_panel:set_state(TileState.Poison)
                prev_panel = user:get_current_tile()
            end
        end

        actor:register_component(component)




        local buster = self:add_attachment("BUSTER")
        buster:sprite():set_texture(gunhilt, true)
        buster:sprite():set_layer(-1)

        local buster_anim = buster:get_animation()
        buster_anim:load(_folderpath .. "player_fx3B_animations.animation")
        buster_anim:set_state("0")
        buster_anim:refresh(buster:sprite())

        buster_anim:set_state("1")
        buster_anim:set_playback(Playback.Loop)
        buster_anim:refresh(buster:sprite())

        action:add_anim_action(2, function()
            local ray_of_sun = summon_sun(user)
            local tile = user:get_tile(user:get_facing(), 2)
            actor:get_field():spawn(ray_of_sun, tile)
        end)
    end
    return action
end

function summon_sun(user)
    local spell = Battle.Spell.new(user:get_team())
    local framedata = 0

    spell:set_facing(user:get_facing())
    spell:set_texture(sunray)

    local anim = spell:get_animation()
    anim:load(_folderpath .. "player_fx3c_animations.animation")
    anim:set_state("0")
    anim:set_playback(Playback.Loop)
    anim:refresh(spell:sprite())
    spell:sprite():set_layer(-1)
    local sun_noise_countdown = 0
    local sun_noise = Engine.load_audio(_folderpath.."song329.ogg", true)
    spell.update_func = function(self, dt)
        if framedata >= 121 then
            self:delete()
        else
            if framedata > 0 then
                local call_hit = spell_damage_summon(user, dt)
                local tile = user:get_tile(user:get_facing(), 2)
                user:get_field():spawn(call_hit, tile)
                if sun_noise_countdown <= 0 then
                    Engine.play_audio(sun_noise, AudioPriority.High)
                    sun_noise_countdown = 2
                end
                sun_noise_countdown = sun_noise_countdown - 1
            end
        end
        framedata = framedata + 1
    end

    spell.can_move_to_func = function(self, other)
        return true
    end

    return spell
end

function spell_damage_summon(user)
    local spell_damage = Battle.Spell.new(user:get_team())
    local damage = 4
    spell_damage:set_hit_props(
        HitProps.new(
            damage,
            Hit.Pierce | Hit.Retangible,
            Element.None,
            user:get_context(),
            Drag.None
        )
    )
    spell_damage.update_func = function(self, dt)
        local own_tile = self:get_tile() --Dawn: get the tile this entity is on
        if not own_tile or own_tile and own_tile:is_edge() then
            self:delete()
        else
            own_tile:highlight(Highlight.Flash)
            own_tile:attack_entities(self)
            if user:get_rank() == Rank.NM then
                own_tile:set_state(TileState.Poison)
            end
        end
        local up_tile = own_tile:get_tile(Direction.Up, 1) --Dawn: get the tile above
        if up_tile and not up_tile:is_edge() then
            up_tile:highlight(Highlight.Flash)
            up_tile:attack_entities(self)
            if user:get_rank() == Rank.NM then
                up_tile:set_state(TileState.Poison)
            end
        end
        local down_tile = own_tile:get_tile(Direction.Down, 1) --Dawn: get the tile below
        if down_tile and not down_tile:is_edge() then
            down_tile:highlight(Highlight.Flash)
            down_tile:attack_entities(self)
            if user:get_rank() == Rank.NM then
                down_tile:set_state(TileState.Poison)
            end
        end
        self:erase()
    end

    return spell_damage
end

return chip