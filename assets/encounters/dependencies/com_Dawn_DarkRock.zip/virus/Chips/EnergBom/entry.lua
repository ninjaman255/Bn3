local bomb = include('bomb/bomb.lua')

bomb.name="EnergBom"
bomb.damage=40
bomb.element=Element.None
bomb.description = "Throws a bomb 3sq ahead"
bomb.codes = {"*"}

function package_init(package)
    local props = package:get_card_props()
    --standard properties
    props.shortname = bomb.name
    props.damage = bomb.damage
    props.time_freeze = false
    props.element = bomb.element
    props.description = bomb.description

    package:declare_package_id("rune.legacy.megenbom")
    package:set_icon_texture(Engine.load_texture(_modpath .. "icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath .. "preview.png"))
    package:set_codes(bomb.codes)
end

card_create_action = bomb.card_create_action