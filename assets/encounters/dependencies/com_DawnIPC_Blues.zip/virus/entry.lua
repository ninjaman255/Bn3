local function spawn_mob_move(blues)
    local fx = Battle.Artifact.new()
    fx:set_texture(Engine.load_texture(_modpath.."mob_move.png", true))
    local anim = fx:get_animation()
    anim:load(_modpath.."mob_move.animation")
    anim:set_state("DEFAULT")
    anim:refresh(fx:sprite())
    anim:on_complete(function()
        fx:erase()
    end)
    local field = blues:get_field()
    field:spawn(fx, blues:get_tile())
end

local function buster_spam_action(blues)
    local spell = Battle.Spell.new(blues:get_team())
    spell.slide_started = false
    spell:set_facing(blues:get_facing())
    spell:set_hit_props(
        HitProps.new(
            5,
            Hit.Impact,
            Element.None,
            blues:get_context(),
            Drag.None
        )
    )
    spell.update_func = function(self, dt) 
        self:get_current_tile():attack_entities(self)
        if self:is_sliding() == false then
            if self:get_current_tile():is_edge() and self.slide_started then 
                self:delete()
            end 
			
            local dest = self:get_tile(spell:get_facing(), 1)
            local ref = self
            self:slide(dest, frames(1), frames(0), ActionOrder.Voluntary, 
                function()
                    ref.slide_started = true 
                end
            )
        end
    end
    spell.collision_func = function(self, other)
		self:delete()
	end
    spell.attack_func = function(self, other) 
    end

    spell.delete_func = function(self)
		self:erase()
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    Engine.play_audio(AudioType.BusterPea, AudioPriority.Low)
    return spell
end

function package_init(self)
    --meta
    self:set_name("ProtoMan")
    self:set_health(2700)
    self:set_texture(Engine.load_texture(_modpath.."blues.png"))

    local anim = self:get_animation()
    anim:load(_modpath.."blues.animation")
    anim:set_state("PLAYER_IDLE")
    local MCannon = include("Chips/MCannon/entry.lua")
    local MoonBld = include("Chips/MoonBld/entry.lua")
    local WideSwrd = include("Chips/WideSwrd/entry.lua")
    local LongSwrd = include("Chips/LongSwrd/entry.lua")
    local Wideblde = include("Chips/Wideblde/entry.lua")
    local Longblde = include("Chips/Longblde/entry.lua")
    local FireSwrd = include("Chips/FireSwrd/entry.lua")
    local AquaSwrd = include("Chips/AquaSwrd/entry.lua")
    local BambSwrd = include("Chips/BambSwrd/entry.lua")
    local ElecSwrd = include("Chips/ElecSwrd/entry.lua")
    local Guard = include("Chips/Guard/entry.lua")
    local StepSword = include("Chips/StepSword/entry.lua")
    local StepCross = include("Chips/StepCross/entry.lua")
    local DarkDefense = Battle.DefenseRule.new(2,DefenseOrder.CollisionOnly)
    DarkDefense.filter_statuses_func = function(statuses)
        statuses.flags = statuses.flags & ~Hit.Blind
        return statuses
    end
    self._movement_wait = 10
    self._should_move = true
    self._should_attack = false
    local attack_list = {
        {MCannon,Guard},
        {MCannon, Longblde,StepCross},
        {MCannon, Longblde,StepCross,MoonBld,Guard},
        {Longblde,Wideblde,MCannon,StepCross,StepSword,Guard},
        {StepCross,StepSword},
        {LongSwrd,StepSword,MCannon,MoonBld},
        {LongSwrd,WideSwrd,StepCross},
        {LongSwrd,WideSwrd,ElecSwrd,BambSwrd,AquaSwrd,FireSwrd,Guard},
        {MoonBld,ElecSwrd,BambSwrd,AquaSwrd,FireSwrd,StepSword},
        {Guard,WideSwrd,Longsword}
    }
    local attack_list_index = 10
    local pick_attack_once = true
    local chosen_attack = nil
    local buster_spam_cooldown = 4
    local current_spam_counter = 0
    local roll = -1
    local roll_once = true
    local frame1 = {1, 0.05}
    local frame2 = {2, 0.05}
    local frame3 = {3, 0.05}
    local frame4 = {1, 0.05}
    local frame5 = {2, 0.05}
    local frame6 = {3, 0.05}
    local frame7 = {1, 0.05}
    local frame8 = {2, 0.05}
    local frame9 = {3, 0.05}
    local frame10 = {4, 0.1}
    local frame_sequence = make_frame_data({frame1, frame2, frame3, frame4, frame5, frame6, frame7, frame8, frame9, frame10})
    local health = 2700
    local tile_array = {}
    local do_once = true
    local teleports = 0
    local goal_teleports = 3
    local current_attacks = 0
   self:register_status_callback(Hit.Drag, function()
        self._should_attack = true
        self._should_move = false
        roll = -1
        roll_once = true
        pick_attack_once = true
    end)
    self:register_status_callback(Hit.Stun, function()
        self._should_attack = true
        self._should_move = false
        roll = -1
        roll_once = true
        pick_attack_once = true
    end)
    self:set_float_shoe(true)
    local entity_query = function(ent)
        return Battle.Obstacle.from(ent) ~= nil or Battle.Character.from(ent) ~= nil
    end
    self.can_move_to_func = function(tile)
        return tile and tile:is_walkable() and not tile:is_edge() and self:is_team(tile:get_team()) and #tile:find_entities(entity_query) == 0
    end
    self.update_func = function(self, dt)
        if self:get_health() ~= health then
            attack_list_index = math.max(1, math.floor(self:get_health() / 270))
        end
        if current_attacks > 3 then
            self._should_attack = false
            self._should_move = true
            roll = -1
            roll_once = true
            pick_attack_once = true
        end
        if self._should_attack and anim:get_state() == "PLAYER_IDLE" then
            if roll_once then
                roll = math.random(1, 20)
                roll_once = false
            end
            if roll > 5 then
                if pick_attack_once then
                    pick_attack_once = false
                    chosen_attack = attack_list[attack_list_index][math.random(1, #attack_list[attack_list_index])]
                    current_attacks = current_attacks + 1
                    local action = chosen_attack.card_create_action(self)
                    self:card_action_event(action, ActionOrder.Involuntary)
                    if math.random(1, 20) > 10 then
                        self._should_attack = false
                        self._should_move = true
                    end
                    roll = -1
                    roll_once = true
                    pick_attack_once = true
                end
            else
                if pick_attack_once then
                    local action = Battle.CardAction.new(self, "PLAYER_SHOOTING")
                    action:override_animation_frames(frame_sequence)
                    action:set_lockout(make_animation_lockout())
                    action.execute_func = function(act, user)
                        local buster = act:add_attachment("BUSTER")
                        local sprite = buster:sprite()
                        sprite:set_texture(self:get_texture())
                        sprite:enable_parent_shader(true)
                        sprite:set_layer(-1)

                        local buster_anim = buster:get_animation()
                        buster_anim:copy_from(self:get_animation())
                        buster_anim:set_state("BUSTER")
                        buster_anim:refresh(sprite)
                        act:add_anim_action(1, function()
                            --[[local flare = buster:add_attachment("endpoint")
                            local flare_sprite = flare:sprite()
                            flare_sprite:set_texture(Engine.load_texture(_modpath.."pew.png", true))
                            flare_sprite:set_layer(-1)

                            local flare_anim = flare:get_animation()
                            flare_anim:load(_modpath.."pew.animation")
                            flare_anim:set_state("0")
                            flare_anim:refresh(flare_sprite)--]]
                            local spell = buster_spam_action(self)
                            self:get_field():spawn(spell, self:get_tile(self:get_facing(), 1))
                        end)
                        act:add_anim_action(4, function()
                            local spell = buster_spam_action(self)
                            self:get_field():spawn(spell, self:get_tile(self:get_facing(), 1))
                        end)
                        act:add_anim_action(7, function()
                            local spell = buster_spam_action(self)
                            self:get_field():spawn(spell, self:get_tile(self:get_facing(), 1))
                        end)
                    end
                    action.action_end_func = function(self)
                        self._should_attack = false
                        self._should_move = true
                        roll = -1
                        roll_once = true
                        current_attacks = current_attacks + 1
                        pick_attack_once = true
                    end
                    self:card_action_event(action, ActionOrder.Involuntary)
                    current_spam_counter = buster_spam_cooldown
                    pick_attack_once = false
                end
            end
        elseif self._should_move then
            if self._movement_wait <= 0 then
                if do_once then
                    local field = self:get_field()
                    for i = 1, 7, 1 do
                        for j = 1, 4, 1 do
                            local tile = field:tile_at(i, j)
                            if tile and not tile:is_edge() and self.can_move_to_func(tile) then
                                table.insert(tile_array, tile)
                            end
                        end
                    end
                    do_once = false
                end
                if #tile_array == 0 then
                    self._should_attack = true
                    self._should_move = false
                    teleports = 0
                    goal_teleports = math.random(3, 5)
                end
                teleports = teleports + 1
                if teleports >= goal_teleports then
                    self._should_attack = true
                    self._should_move = false
                    teleports = 0
                    goal_teleports = math.random(3, 5)
                else
                    local chosen_tile = tile_array[math.random(1, #tile_array)]
                    self:teleport(chosen_tile, ActionOrder.Immediate, function()
                        spawn_mob_move(self)
                        self._movement_wait = 20
                        current_attacks = 0
                    end)
                end
            else
                self._movement_wait = self._movement_wait - 1
            end
        end
    end
end