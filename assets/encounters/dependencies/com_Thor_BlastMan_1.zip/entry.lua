local package_id = "com.Thor.BlastMan_1"
local character_id = "com.Thor.enemy.BlastMan_V1"
local tink_sfx = Engine.load_audio(_modpath.."tink.ogg")

function package_requires_scripts()
  Engine.define_character(character_id, _modpath.."Blastman_V1")
end

function package_init(package)
  package:declare_package_id(package_id)
  package:set_name("BlastMan")
  package:set_description("BN6 BlastMan Battle!")
  package:set_speed(1)
  package:set_attack(20)
  package:set_health(400)
  package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
local texPath = _modpath.."bg.png"
local animPath = _modpath.."bg.animation"

mob:set_background(texPath, animPath, -0.5, -0.5)

local spawner = mob:create_spawner(character_id,Rank.V1)
spawner:spawn_at(5, 2)
mob:spawn_player(1, 2, 2)

local cube1 = make_cube()
local cube2 = make_cube()

mob:get_field():spawn(cube1, 1, 3)
mob:get_field():spawn(cube2, 4, 1)
end


function make_cube()
	local guarding_defense_rule = Battle.DefenseRule.new(0,DefenseOrder.Always)
	guarding_defense_rule.can_block_func = function(judge, attacker, defender)
		local attacker_hit_props = attacker:copy_hit_props()
		if attacker_hit_props.damage > 0 then
			if attacker_hit_props.flags & Hit.Breaking == Hit.Breaking then
				--cant block breaking hits with guard
				return
			end
			judge:block_impact()
			judge:block_damage()
			Engine.play_audio(tink_sfx, AudioPriority.Highest)
		end
	end
	local blastcube_texture = Engine.load_texture(_modpath .. "blastcube.png")
	local blastcube_animation = _modpath.."blastcube.animation"
	local cube = Battle.Obstacle.new(Team.Other)
	cube:set_texture(blastcube_texture, true)
	cube:get_animation():load(blastcube_animation)
	cube:get_animation():set_state("IDLE")
	cube:get_animation():set_playback(Playback.Loop)
	cube:set_health(999999999)
	cube:share_tile(false)
	cube:add_defense_rule(guarding_defense_rule)
	return cube
end