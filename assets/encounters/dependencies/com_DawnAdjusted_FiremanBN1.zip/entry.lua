local package_id = "com.DawnAdjusted.FiremanBN1"
local character_id = "com.DawnAdjusted.Enemy.FiremanBN1P2"

function package_requires_scripts()
    Engine.define_character(character_id, _modpath.."fireman")
end

function package_init(package) 
    package:declare_package_id(package_id)
    package:set_name("FireManV1 (BN1)")
    package:set_description("Go back to the start! The very first scenario boss in the series.")
    package:set_speed(1)
    package:set_attack(10)
    package:set_health(300)
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob) 
    print("_modpath is: ".._modpath)
    local texPath = _modpath.."background.gif"
    local animPath = _modpath.."background.animation"
    mob:set_background(texPath, animPath, 0.0, 0.0)
    mob:stream_music(_modpath.."music.ogg", 6855, 45408-6855)

    mob:create_spawner(character_id, Rank.V1)
        :spawn_at(5, 2)
end