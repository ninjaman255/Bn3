local idle
local shared_folder_path = _modpath.."../shared/"

local function create_substitute(character)
  local substitute = Battle.Obstacle.new(character:get_team())
  substitute:set_facing(character:get_facing())
  substitute:set_texture(character:get_texture())
  substitute:set_palette(character:get_current_palette())
  substitute:set_height(45)

  substitute.can_move_to_func = function()
    return false
  end

  substitute.update_func = function()
    if character:is_deleted() then
      substitute:delete()
    end
  end

  substitute.delete_func = function()
    substitute:get_field():spawn(Battle.Explosion.new(1, 1), substitute:get_tile())
  end

  local anim = substitute:get_animation()
  anim:copy_from(character:get_animation())
  anim:set_state("HEADLESS")

  character:get_field():spawn(substitute, character:get_tile())

  return substitute
end

local function create_hit_spell(character)
  local spell = Battle.Spell.new(character:get_team())
  spell:set_facing(character:get_facing())
  spell:set_shadow(Shadow.Small)
  spell:show_shadow(true)

  spell:set_hit_props(
    HitProps.new(
      character._damage,
      Hit.Impact | Hit.Flinch | Hit.Flash,
      Element.Wood,
      character:get_context(),
      Drag.None
    )
  )

  spell.update_func = function()
    if character:is_deleted() then
      spell:erase()
    end
  end

  spell.can_move_to_func = function()
    return true
  end

  return spell
end

local function spawn_teleport_out_artifact(character)
  local artifact = Battle.Artifact.new()
  artifact:set_facing(character:get_facing())
  artifact:set_texture(Engine.load_texture(shared_folder_path.."teleport.png"))

  artifact:set_animation(shared_folder_path.."teleport.animation")
  local anim = artifact:get_animation()
  anim:set_state("SMALL_TELEPORT_FROM")
  anim:on_complete(function()
    artifact:erase()
  end)

  local char_offset = character:get_offset()
  local char_tile_offset = character:get_tile_offset()
  artifact:set_offset(char_offset.x + char_tile_offset.x, char_offset.y + char_tile_offset.y)

  character:get_field():spawn(artifact, character:get_tile())
end

local function return_to_body(character, substitute)
  local elevation = 250
  local velocity = 1

  character:set_offset(0, -elevation)
  character:get_tile():remove_entity_by_id(character:get_id())
  substitute:get_tile():add_entity(character)
  character._attacking = false
  character:toggle_hitbox(false)

  local animation = character:get_animation()
  animation:set_state("HEAD")
  animation:set_playback(Playback.Loop)

  character.update_func = function()
    elevation = elevation - velocity
    velocity = velocity + 1
    character:set_offset(0, -elevation)

    if elevation < 25 then
      character:toggle_hitbox(true)
      character:set_offset(0, 0)
      idle(character)
      substitute:erase()
    end
  end
end

local function begin_rolling(character)
  local animation = character:get_animation()
  animation:set_state("ROLLIN")
  animation:set_playback(Playback.Loop)
  character:hide()
  character._attacking = true

  local substitute = create_substitute(character)
  local spell = create_hit_spell(character)
  local counter = 0

  local start_tile = character:get_tile(character:get_facing(), 1)
  character:get_field():spawn(spell, start_tile)
  character:teleport(start_tile, ActionOrder.Voluntary, function()
    character:share_tile(true)
  end)

  local function complete()
    -- swapping the update_func to delay by one frame as
    -- the head is still moving and needs a frame to stop
    character.update_func = function()
      spawn_teleport_out_artifact(character)

      character:set_offset(0, 0)
      spell:erase()
      character:share_tile(false)

      return_to_body(character, substitute)
    end
  end

  character.update_func = function()
    if counter == 1 then
      character:reveal()
    end

    counter = counter + 1

    if counter < 2 then
      return
    end

    local wrapped_counter = (counter) % 20
    local current_tile = character:get_tile()

    character:set_offset(0, -40 * math.sin(math.pi * wrapped_counter / 20))
    current_tile:attack_entities(spell)

    local offset = character:get_tile_offset()
    spell:set_offset(offset.x, offset.y)

    spell:get_tile():remove_entity_by_id(spell:get_id())
    current_tile:add_entity(spell)

    if #current_tile:find_obstacles(function() return true end) > 0 then
      complete()
      return
    end

    if character:is_moving() then
      return
    end

    if not current_tile:is_walkable() then
      complete()
      return
    end

    local dest_tile = character:get_tile(character:get_facing(), 1)

    if dest_tile == nil then
      complete()
      return
    end

    character:slide(dest_tile, frames(20), frames(0), ActionOrder.Voluntary, function()
      Engine.play_audio(character._bounce_sfx, AudioPriority.Highest)
    end)
  end
end

local function begin_attack(character)
  local action = Battle.CardAction.new(character, "ATTACK")

  action.animation_end_func = function()
    Engine.play_audio(character._throw_sfx, AudioPriority.High)
    begin_rolling(character)
  end

  action.execute_func = function()
    character:toggle_counter(true)
  end

  action.action_end_func = function()
    character:toggle_counter(false)
  end

  character.update_func = function() end
  character:card_action_event(action, ActionOrder.Voluntary)
end

idle = function(character)
  character.update_func = function() end

  local animation = character:get_animation()

  animation:set_state("IDLE")
  animation:set_playback(Playback.Loop)
  animation:on_complete(function()
    -- reset complete function
    animation:on_complete(function() end)

    local remaining_ticks = math.random(72*2)

    character.update_func = function()
      remaining_ticks = remaining_ticks - 1

      if remaining_ticks == 0 then
        begin_attack(character)
      end
    end
  end)
end

local function package_init(character)
  character:set_height(45)
  character:set_element(Element.Wood)

  character._attacking = false
  character._damage = 20
  character:set_texture(Engine.load_texture(shared_folder_path.."battle.greyscaled.png"))
  character:set_animation(shared_folder_path.."battle.animation")
  character:get_animation():set_state("INIT")

  character._bounce_sfx = Engine.load_audio(shared_folder_path.."panel_crack.ogg") -- wrong sound, but the closest we have
  character._throw_sfx = Engine.load_audio(shared_folder_path.."puck_launch.ogg")

  character:add_defense_rule(Battle.DefenseVirusBody.new())

  character.can_move_to_func = function (tile)
    if character._attacking then
      return true
    end

    if not tile:is_walkable() or tile:get_team() ~= character:get_team() then
      return false
    end

    local has_character = false

    tile:find_entities(function(c)
      if Battle.Character.from(c) or Battle.Obstacle.from(c) then
        has_character = true
      end
      return false
    end)

    return not has_character
  end

  character.battle_start_func = function()
    idle(character)
  end
end

return package_init
