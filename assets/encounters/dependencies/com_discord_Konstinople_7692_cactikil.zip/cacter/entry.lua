local shared_package_init = include("../shared/entry.lua")

function package_init(character)
  shared_package_init(character)
  character:set_name("Cacter")

  if character:get_rank() == Rank.EX then
    character:set_health(270)
    character._damage = 200
    character:set_palette(Engine.load_texture(_modpath.."cacterEX.palette.png"))
  else
    character:set_health(230)
    character._damage = 150
    character:set_palette(Engine.load_texture(_modpath.."cacter.palette.png"))
  end
end
