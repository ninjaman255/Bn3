local shared_package_init = include("../shared/entry.lua")

function package_init(character)
  shared_package_init(character)

  if character:get_rank() == Rank.EX then
    character:set_name("Cactkl")
    character:set_health(110)
    character._damage = 40
    character:set_palette(Engine.load_texture(_modpath.."cactikilEX.palette.png"))
  else
    character:set_name("Cactikil")
    character:set_health(70)
    character._damage = 20
    character:set_palette(Engine.load_texture(_modpath.."cactikil.palette.png"))
  end
end
